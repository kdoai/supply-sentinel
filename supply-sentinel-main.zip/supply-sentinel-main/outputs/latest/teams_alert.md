# [Supply Sentinel] High supply risk detected

Material: naphtha
Risk score: 82/100
Severity: HIGH
Estimated minimum inventory days: 5
Affected period: next two to three weeks

## Impact
- Products: 樹脂A, 溶剤B, コーティングC
- Customers: 自動車部品A社, 包装材B社, 化学品C社
- Plants: 千葉工場, 大阪工場

## Evidence
- News headline: Naphtha supply tightens after refinery disruption in Asia
- Supplier/news text indicates 5-7 day shipment delay.
- Supplier/news text indicates allocation may be limited to 70% of normal volume.
- Supplier notice subject: Temporary allocation control for naphtha-derived feedstock
- Confidence judged as high from source reliability and explicit numeric/date signals.

## Recommended First Actions
- サプライヤへ最新の割当数量・出荷予定・代替出荷枠を確認する。
- 高優先度受注・重要工場向けに利用可能在庫を仮引当する。
- 承認済み代替材（NAP-ALT-01）の適用範囲・リードタイム・顧客制約を確認する。
- 高優先顧客向けに影響可能性と暫定納期の説明ドラフトを作成する。
- 生産計画を5-7日の遅延幅で再評価する。

## Human Approval Required
- 発注内容の変更
- サプライヤ切替
- 顧客への正式通知
- 生産計画の大幅変更
