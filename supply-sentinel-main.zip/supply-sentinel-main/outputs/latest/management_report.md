# Supply Risk Report

## Executive Summary

Supply Sentinel detected a high supply risk for naphtha. The risk score is 82/100, with minimum inventory coverage of 5 days across the current sample data.

## Evidence

- News headline: Naphtha supply tightens after refinery disruption in Asia
- Supplier/news text indicates 5-7 day shipment delay.
- Supplier/news text indicates allocation may be limited to 70% of normal volume.
- Supplier notice subject: Temporary allocation control for naphtha-derived feedstock
- Confidence judged as high from source reliability and explicit numeric/date signals.

## Business Impact

- Impacted products: 樹脂A, 溶剤B, コーティングC
- Impacted customers: 自動車部品A社, 包装材B社, 化学品C社
- Impacted plants: 千葉工場, 大阪工場
- Minimum inventory days: 5
- Allocation rate indicated by supplier: 70%
- Delay window: 5-7 days

## Recommended Initial Actions

- サプライヤへ最新の割当数量・出荷予定・代替出荷枠を確認する。
- 高優先度受注・重要工場向けに利用可能在庫を仮引当する。
- 承認済み代替材（NAP-ALT-01）の適用範囲・リードタイム・顧客制約を確認する。
- 高優先顧客向けに影響可能性と暫定納期の説明ドラフトを作成する。
- 生産計画を5-7日の遅延幅で再評価する。

## Decisions Requiring Approval

- 発注内容の変更
- サプライヤ切替
- 顧客への正式通知
- 生産計画の大幅変更

## Scoring Basis

- external_event_severity: 24
- supplier_notice_confidence: 15
- inventory_days_risk: 20
- customer_order_priority: 10
- alternative_availability_risk: 6
- affected_supply_ratio_risk: 4
- spend_at_risk_scale: 3

## Next Monitoring Point

Re-check supplier allocation status and unresolved high-priority customer exposure on the next scheduled run.
