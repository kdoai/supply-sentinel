// aiScenarioBrief.js — AI Scenario Brief(AI判断補助サマリ)。
//
// 単なるスライダー連動グラフ(BIダッシュボード)との差別化点。AIが意思決定支援に
// 効いていることを示すパネル。重要原則(指示書§12):
//   - 入力は「計算済みの metrics / 製品判断 / 企業ポリシー / トレンド」のみ。
//   - AIは新しい数値を作らない。数値はすべてルールベース計算の引用。
//   - AIの役割は、判断理由の説明・打ち手の整理・追加確認ポイント・経営/顧客向け要約。
//
// buildScenarioBrief は純粋関数(DOM非依存)で、出力に現れる数値はすべて入力由来。
// renderScenarioBrief が DOM 描画を担い、ローカル生成(デモ)か cloud かを明示する。

const MATERIAL_LABELS = {
  naphtha: "ナフサ",
  pp: "PP",
  pe: "PE",
  abs: "ABS",
  "packaging-film": "包装フィルム",
  "semiconductor-adhesive": "半導体接着材",
  "other-petrochemical": "その他石化素材",
};

const PERIOD_LABELS = { 7: "1週間", 14: "2週間", 30: "1か月", 90: "3か月" };
const DEMAND_LABELS = {
  protect_priority_customers: "高優先顧客を守る",
  maximize_revenue: "売上最大化",
  keep_production: "生産継続優先",
  even_allocation: "全顧客均等配分",
};

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
function asArray(v) {
  return Array.isArray(v) ? v : [];
}
function materialLabel(m) {
  return MATERIAL_LABELS[m] || m || "対象素材";
}
function compactUsdJa(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "0ドル";
  if (Math.abs(n) >= 1_000_000) return `${trim1(n / 1_000_000)}百万ドル`;
  if (Math.abs(n) >= 1_000) return `${trim1(n / 1_000)}千ドル`;
  return `${Math.round(n).toLocaleString("ja-JP")}ドル`;
}
function trim1(num) {
  const s = num.toFixed(1);
  return s.endsWith(".0") ? s.slice(0, -2) : s;
}
function names(list, picker) {
  return asArray(list).map(picker).filter(Boolean);
}

/**
 * 計算済みデータから AI Scenario Brief を組み立てる(純粋・決定論)。
 * 出力中の数値はすべて引数由来で、ここで新しい数値は作らない。
 */
export function buildScenarioBrief(input = {}) {
  const scenario = input.scenario || {};
  const metrics = input.metrics || {};
  const policy = input.policy || {};
  const controls = input.controls || {};
  const decisions = input.decisions || {};
  const trend = input.trend || null;

  const material = materialLabel(scenario.material || metrics.material);
  const reduction = Number(controls.reductionPercent);
  const periodLabel = PERIOD_LABELS[controls.period] || `${controls.period || "-"}日`;
  const policyName = policy.company_policy_name || "企業ポリシー";

  const affectedRatio = metrics.affected_supply_ratio;
  const invDays = metrics.inventory_days_min;
  const spend = metrics.spend_at_risk_usd;
  const riskScore = metrics.risk_score;
  const products = asArray(decisions.products);
  const buckets = decisions.buckets || {};

  const protect = names(buckets.protect, (p) => p.product);
  const reduce = names(buckets.reduce, (p) => p.product);
  const pullIn = names(buckets.pull_in, (p) => p.product);
  const restock = names(buckets.restock, (p) => p.product);
  const diversify = names(buckets.diversify, (p) => p.product);
  const altMaterials = asArray(buckets.alt_materials);
  const impactedProducts = asArray(metrics.impacted_products);
  const impactedCustomers = asArray(metrics.impacted_customers);

  // 期間内に在庫で耐えられるか(在庫残日数 vs 影響期間)。数値は入力由来。
  const enduresPeriod = invDays != null && Number(invDays) >= Number(controls.period);
  const enduranceText = invDays == null
    ? ""
    : enduresPeriod
      ? `最短在庫${invDays}日は影響期間(${periodLabel})を概ねカバーできる見込みです。`
      : `最短在庫${invDays}日では影響期間(${periodLabel})を在庫だけで吸収しきれません。`;

  // 経営向け要約(数値は metrics 引用のみ)。
  const execBits = [];
  execBits.push(`供給${Number.isFinite(reduction) ? `${reduction}%減` : "減少"}・影響期間${periodLabel}の前提で、${material}調達の${affectedRatio ?? "-"}%が影響を受けます。`);
  if (invDays != null) execBits.push(`最短在庫は${invDays}日。`);
  if (spend != null) execBits.push(`金額影響は月${compactUsdJa(spend)}。`);
  execBits.push(`${policyName}に基づき、${protect.length}製品を優先保護(供給配分)、${reduce.length}製品を縮小候補として扱います。`);
  const exec_summary = execBits.join("");

  // 製品優先順位の理由(上位の製品の判断理由を引用)。
  const priority_reasons = products.slice(0, 4).map((p) => {
    return `${p.product}(優先${p.priority_rank}位 / ${p.decision_label}): ${asArray(p.reasons).join(" / ")}`;
  });

  // 追加確認ポイント(ルールベース結果から導出。AIが新規データを作らない)。
  const confirm_points = [];
  if (diversify.length) confirm_points.push(`代替・分散調達の余力(${diversify.join("・")}の被影響ルート集中の解消可否)`);
  if (altMaterials.some((a) => !a.approved)) confirm_points.push("未承認代替材の顧客承認範囲(顧客出荷品への適用可否)");
  if (impactedCustomers.length) confirm_points.push(`高優先顧客(${impactedCustomers.slice(0, 2).join("・")})の納期許容幅`);
  if (pullIn.length || restock.length) confirm_points.push("生産前倒し・在庫積み増しが何日分可能か");
  if (!confirm_points.length) confirm_points.push("現時点で追加確認が必要な重大論点はありません(通常監視)。");

  // 顧客説明ドラフト(送信は人間承認後)。
  const customer_draft = impactedCustomers.length
    ? `平素より格別のお引き立てを賜り御礼申し上げます。${material}の供給制約に伴い、${impactedProducts.slice(0, 3).join("・") || "一部製品"}の供給に影響が生じる可能性がございます。現時点の最短在庫は${invDays ?? "-"}日で、影響期間は${periodLabel}を想定しております。暫定納期・代替案を別途ご提示し、次回○月○日までに進捗をご連絡いたします。(本文案はドラフトです。正式送信は営業責任者の承認後に行います)`
    : "影響顧客が特定されていないため、顧客向け説明文案は未作成です。";

  const human_approvals = asArray(decisions.human_approvals);

  return {
    mode: "local",
    fallback: true,
    material,
    exec_summary,
    endurance_text: enduranceText,
    priority_reasons,
    protect,
    reduce,
    pull_in: pullIn,
    restock,
    diversify,
    alt_check: altMaterials,
    confirm_points,
    customer_draft,
    human_approvals,
    trend,
    references: {
      risk_score: riskScore,
      affected_supply_ratio: affectedRatio,
      inventory_days_min: invDays,
      spend_at_risk_usd: spend,
      impacted_products: impactedProducts.length,
      impacted_customers: impactedCustomers.length,
      policy: policyName,
    },
  };
}

// AI Scenario Brief を描画する。fallback(ローカル決定論生成)は「デモ回答・ローカル生成」と明示。
export function renderScenarioBrief(containerEl, brief, options) {
  if (!containerEl || !brief) return;
  const opts = options || {};
  const badge = brief.fallback
    ? "ローカル生成(デモ回答 / 数値はルールベース計算の引用)"
    : `${esc(opts.model || "Azure OpenAI")} / cloud`;

  // 実Web調査(ライブ取得)の差分。手動「シナリオ実行」で実取得できた時のみ表示。
  const research = opts.research;
  const researchHtml = research && research.mode !== "unavailable" && asArray(research.evidence).length
    ? `
      <section class="brief-section brief-research">
        <h4>実ニュース調査（ライブ） <span class="brief-trend-badge brief-trend-${esc(research.diff?.outlook || "stable")}">${esc(researchOutlookLabel(research.diff?.outlook))}</span></h4>
        <p class="brief-trend-headline">${esc(research.diff?.headline || "")}</p>
        <ul>${asArray(research.diff?.summary_points).map((t) => `<li>${esc(t)}</li>`).join("")}</ul>
        <p class="brief-research-meta">取得: ${esc(research.evidence.length)}件 / ${esc(researchModeText(research.mode))}${research.queries?.length ? ` / 検索: ${research.queries.slice(0, 3).map((q) => esc(q)).join(" ・ ")}` : ""}</p>
        <ul class="brief-research-links">
          ${asArray(research.evidence).slice(0, 5).map((e) => `<li><a href="${esc(e.url)}" target="_blank" rel="noreferrer">${esc(e.title)}</a>${e.source ? ` <span>(${esc(e.source)})</span>` : ""}</li>`).join("")}
        </ul>
      </section>`
    : "";

  const trend = brief.trend;
  const trendHtml = trend && trend.hasPrevious
    ? `
      <section class="brief-section brief-trend">
        <h4>差分・トレンド(前回比) <span class="brief-trend-badge brief-trend-${esc(trend.news_outlook)}">${esc(newsLabel(trend.news_outlook))}</span></h4>
        <p class="brief-trend-headline">${esc(trend.headline)}</p>
        <ul>${asArray(trend.summary_points).map((t) => `<li>${esc(t)}</li>`).join("")}</ul>
      </section>`
    : trend
      ? `<section class="brief-section brief-trend"><h4>差分・トレンド(前回比)</h4><p>${esc(trend.headline)}</p></section>`
      : "";

  const listSection = (title, items, picker = (x) => x) => {
    const arr = asArray(items).map(picker).filter(Boolean);
    if (!arr.length) return "";
    return `<section class="brief-section"><h4>${esc(title)}</h4><ul>${arr.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></section>`;
  };

  containerEl.innerHTML = `
    <div class="brief-head">
      <span class="brief-kicker">AI Scenario Brief / AI判断補助サマリ</span>
      <span class="brief-badge">${esc(badge)}</span>
    </div>
    <section class="brief-section brief-exec">
      <h4>経営向け要約</h4>
      <p>${esc(brief.exec_summary)}</p>
      ${brief.endurance_text ? `<p class="brief-endurance">${esc(brief.endurance_text)}</p>` : ""}
    </section>
    ${researchHtml}
    ${trendHtml}
    ${listSection("製品優先順位の理由", brief.priority_reasons)}
    ${listSection("守るべき製品(供給配分)", brief.protect)}
    ${listSection("縮小候補製品", brief.reduce)}
    ${listSection("代替材確認が必要な部材", brief.alt_check, (a) => `${a.material}${a.approved ? "(承認済み・制約あり)" : "(未承認)"}`)}
    ${listSection("在庫積み増し候補", brief.restock)}
    ${listSection("調達先分散候補", brief.diversify)}
    ${listSection("生産前倒し候補", brief.pull_in)}
    ${listSection("追加確認ポイント", brief.confirm_points)}
    <section class="brief-section brief-customer">
      <h4>顧客説明ドラフト(送信は承認後)</h4>
      <p>${esc(brief.customer_draft)}</p>
    </section>
    ${listSection("人間承認が必要な判断", brief.human_approvals)}
    <p class="brief-foot">AIエージェントは外部情報の調査・リスク抽出・差分判定・初動起案を担当し、数値(リスク${esc(brief.references.risk_score ?? "-")} / 影響供給比率${esc(brief.references.affected_supply_ratio ?? "-")}% / 最短在庫${esc(brief.references.inventory_days_min ?? "-")}日)はルールベース計算で検証しています。判定基準: ${esc(brief.references.policy)}。</p>`;
}

function newsLabel(outlook) {
  return { improving: "ニュース好転", worsening: "ニュース悪化", stable: "横ばい" }[outlook] || "横ばい";
}

function researchOutlookLabel(outlook) {
  return { improving: "ニュース好転(実取得)", worsening: "ニュース悪化(実取得)", stable: "横ばい(実取得)" }[outlook] || "横ばい";
}

function researchModeText(mode) {
  return { agent: "AI自律検索(LLM+実ニュース)", rss: "実ニュース検索(RSS)" }[mode] || mode || "実取得";
}
