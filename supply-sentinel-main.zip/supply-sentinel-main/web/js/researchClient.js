// researchClient.js — 「シナリオ実行」から実Web調査エンドポイント(/api/research)を叩く。
//
// バックエンド(serve.mjs / Azure Functions)が稼働している時だけ実ニュースを取得できる。
// 静的ホスティング(GitHub Pages 等)やネットワーク不通では null を返し、呼び出し側は
// 決定論のデモ差分へフォールバックする(誤って「ライブ」と見せない)。
//
// 前回スナップショットは localStorage に素材別で保持し、次回実行時の差分比較に渡す。

const SNAP_KEY = "supply-sentinel.research-snapshots";

export function researchEndpointUrl(apiBase) {
  const base = String(apiBase || "").replace(/\/$/, "");
  return base ? `${base}/api/research` : "/api/research";
}

export async function requestScenarioResearch({ apiBase, material, materialLabel, previous }) {
  try {
    const res = await fetch(researchEndpointUrl(apiBase), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ material, materialLabel, previous: previous || null }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

function storageAvailable() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return false;
  }
}

function readAll() {
  if (!storageAvailable()) return {};
  try {
    const raw = localStorage.getItem(SNAP_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

export function loadSnapshot(material) {
  const all = readAll();
  return all[material] || null;
}

export function saveSnapshot(material, snapshot) {
  if (!storageAvailable() || !material || !snapshot) return;
  try {
    const all = readAll();
    all[material] = snapshot;
    localStorage.setItem(SNAP_KEY, JSON.stringify(all));
  } catch {
    /* 容量超過等は無視(差分はスキップされるだけ) */
  }
}

export function researchModeLabel(mode) {
  return {
    agent: "AI自律検索(LLM+実ニュース)",
    rss: "実ニュース検索(RSS)",
    unavailable: "ライブ取得不可",
  }[mode] || mode || "不明";
}
