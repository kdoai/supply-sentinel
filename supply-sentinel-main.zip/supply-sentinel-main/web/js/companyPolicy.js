// companyPolicy.js — 企業判断基準(注意/危険/停止判断の閾値・製品優先順位の重み)
//
// このツールの中心思想: 注意/危険/停止の閾値や優先順位の重みは「アプリが定めた
// 正解」ではなく、企業ごとのSCMチームが設定するものである。したがって本モジュールは
//   1) 企業ポリシー(閾値 + 重み)を保持・編集・永続化し、
//   2) その基準に基づく純粋関数 classifyWarningLevel / productPriorityScore を提供する。
// 数値計算(在庫日数・影響供給比率など)はルールベース(propagationEngine)が担い、
// 本モジュールは「その企業基準でどう判定されるか」だけを受け持つ。
//
// 純粋関数(classifyWarningLevel / productPriorityScore / normalizePolicy 等)は
// DOM にも localStorage にも触れないため Node のテストから直接 import できる。
// 描画(renderPolicyPanel)と永続化(loadPolicy/savePolicy)だけが副作用を持つ。

const STORAGE_KEY = "supply-sentinel.company-policy";

// 既定の企業ポリシー(= web/assets/company_policy.demo.json と同値)。
// fetch に失敗してもオフラインで動くよう、ここに正本のコピーを埋め込む。
export const DEFAULT_POLICY = {
  company_policy_name: "Demo Manufacturing SCM Policy",
  note: "これはアプリが定めた正しい基準ではなく、デモ企業の設定例です。",
  thresholds: {
    attention: { min_inventory_days: 30, affected_supply_ratio_percent: 20 },
    danger: { min_inventory_days: 14, affected_supply_ratio_percent: 50 },
    stop_or_allocation_decision: { min_inventory_days: 7, affected_supply_ratio_percent: 70 },
  },
  priority_weights: {
    customer_priority: 0.3,
    revenue_impact: 0.25,
    inventory_days: 0.2,
    alternative_availability: 0.15,
    single_supplier_dependency: 0.1,
  },
};

// 警戒レベル(深刻度の高い順)。none は要対応シグナルなし。
export const WARNING_LEVELS = ["stop_or_allocation_decision", "danger", "attention", "none"];

const WARNING_LABELS = {
  stop_or_allocation_decision: "停止・供給配分判断",
  danger: "危険",
  attention: "注意",
  none: "通常",
};

const WEIGHT_KEYS = [
  "customer_priority",
  "revenue_impact",
  "inventory_days",
  "alternative_availability",
  "single_supplier_dependency",
];

const WEIGHT_LABELS = {
  customer_priority: "顧客優先度",
  revenue_impact: "売上影響",
  inventory_days: "在庫日数",
  alternative_availability: "代替材有無",
  single_supplier_dependency: "単一サプライヤ依存",
};

const THRESHOLD_KEYS = ["attention", "danger", "stop_or_allocation_decision"];

const THRESHOLD_LABELS = {
  attention: "注意判定",
  danger: "危険判定",
  stop_or_allocation_decision: "停止・供給配分判断",
};

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function num(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

// --- 純粋ロジック -----------------------------------------------------------

// 任意の入力を有効なポリシー形に整える(欠損は既定値で補完)。
export function normalizePolicy(policy) {
  const src = policy && typeof policy === "object" ? policy : {};
  const th = src.thresholds || {};
  const w = src.priority_weights || {};
  const out = {
    company_policy_name: typeof src.company_policy_name === "string" && src.company_policy_name.trim()
      ? src.company_policy_name.trim()
      : DEFAULT_POLICY.company_policy_name,
    note: typeof src.note === "string" ? src.note : DEFAULT_POLICY.note,
    thresholds: {},
    priority_weights: {},
  };
  for (const key of THRESHOLD_KEYS) {
    const d = DEFAULT_POLICY.thresholds[key];
    const v = th[key] || {};
    out.thresholds[key] = {
      min_inventory_days: num(v.min_inventory_days, d.min_inventory_days),
      affected_supply_ratio_percent: num(v.affected_supply_ratio_percent, d.affected_supply_ratio_percent),
    };
  }
  for (const key of WEIGHT_KEYS) {
    out.priority_weights[key] = num(w[key], DEFAULT_POLICY.priority_weights[key]);
  }
  return out;
}

// 在庫残日数と(製品/拠点単位の)影響供給比率を、企業の閾値に照らして警戒レベルへ分類する。
// 各レベルは「在庫日数が閾値以下」または「影響供給比率が閾値以上」で成立し、
// 深刻度の高いレベルから順に判定する。閾値を変えれば判定が変わる(受け入れ基準§21.3)。
export function classifyWarningLevel(inventoryDays, affectedRatioPercent, policy) {
  const p = normalizePolicy(policy);
  const invDays = inventoryDays == null ? null : num(inventoryDays, null);
  const ratio = num(affectedRatioPercent, 0);
  for (const level of ["stop_or_allocation_decision", "danger", "attention"]) {
    const t = p.thresholds[level];
    const byInventory = invDays != null && invDays <= t.min_inventory_days;
    const byRatio = ratio >= t.affected_supply_ratio_percent;
    if (byInventory || byRatio) return level;
  }
  return "none";
}

export function warningLevelLabel(level) {
  return WARNING_LABELS[level] || level || "通常";
}

// 製品の優先順位スコア(0〜1)。各 factor は 0〜1 に正規化済み(高いほど「守る」優先度が高い):
//   customer_priority: 顧客優先度(high=1.0 / medium=0.6 / low=0.3)
//   revenue_impact:    売上影響(製品間で正規化)
//   inventory_days:    在庫逼迫度(残日数が短いほど高い)
//   alternative_availability: 代替の効きにくさ(承認済み代替がないほど高い)
//   single_supplier_dependency: 供給集中度(単一/高集中ほど高い)
// 重みを変えれば製品順位が変わる(受け入れ基準§21.4)。
export function productPriorityScore(factors, weights) {
  const f = factors && typeof factors === "object" ? factors : {};
  const w = normalizeWeights(weights);
  let score = 0;
  for (const key of WEIGHT_KEYS) {
    score += clamp01(num(f[key], 0)) * w[key];
  }
  return Math.round(score * 1000) / 1000;
}

function normalizeWeights(weights) {
  const src = weights && typeof weights === "object" ? weights : {};
  const out = {};
  for (const key of WEIGHT_KEYS) {
    out[key] = num(src[key], DEFAULT_POLICY.priority_weights[key]);
  }
  return out;
}

function clamp01(v) {
  return Math.max(0, Math.min(1, v));
}

// 需要方針(scenarioControls の demand)に応じて、優先順位の重みを微調整した
// コピーを返す。元の企業ポリシーは変更しない。AIではなくルールベースの調整。
export function applyDemandPolicy(weights, demandPolicy) {
  const w = normalizeWeights(weights);
  const out = { ...w };
  switch (demandPolicy) {
    case "protect_priority_customers":
      out.customer_priority = w.customer_priority * 1.5;
      break;
    case "maximize_revenue":
      out.revenue_impact = w.revenue_impact * 1.6;
      break;
    case "keep_production":
      out.inventory_days = w.inventory_days * 1.5;
      out.single_supplier_dependency = w.single_supplier_dependency * 1.3;
      break;
    case "even_allocation":
      // 全顧客均等: 顧客優先度の効きを抑える。
      out.customer_priority = w.customer_priority * 0.5;
      break;
    default:
      break;
  }
  return out;
}

// --- 永続化(localStorage、副作用あり) -------------------------------------

let memoryPolicy = null;

function storageAvailable() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return false;
  }
}

// 基準ポリシー(fetch等で得た正本)に、localStorage の編集差分を重ねて返す。
export function loadPolicy(basePolicy) {
  const base = normalizePolicy(basePolicy || DEFAULT_POLICY);
  if (storageAvailable()) {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") return mergePolicy(base, parsed);
      }
    } catch {
      /* 破損時は基準を返す */
    }
  }
  if (memoryPolicy) return mergePolicy(base, memoryPolicy);
  return base;
}

export function savePolicy(policy) {
  const normalized = normalizePolicy(policy);
  if (storageAvailable()) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
      return normalized;
    } catch {
      /* 書込不可時はメモリへ縮退 */
    }
  }
  memoryPolicy = normalized;
  return normalized;
}

export function resetPolicy() {
  if (storageAvailable()) {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
  }
  memoryPolicy = null;
}

function mergePolicy(base, override) {
  // override は基準と同形 or 部分。normalizePolicy で形を整えてから上書き。
  const merged = {
    company_policy_name: base.company_policy_name,
    note: base.note,
    thresholds: JSON.parse(JSON.stringify(base.thresholds)),
    priority_weights: { ...base.priority_weights },
  };
  const oth = override.thresholds || {};
  for (const key of THRESHOLD_KEYS) {
    if (oth[key]) {
      if (oth[key].min_inventory_days != null) merged.thresholds[key].min_inventory_days = num(oth[key].min_inventory_days, merged.thresholds[key].min_inventory_days);
      if (oth[key].affected_supply_ratio_percent != null) merged.thresholds[key].affected_supply_ratio_percent = num(oth[key].affected_supply_ratio_percent, merged.thresholds[key].affected_supply_ratio_percent);
    }
  }
  const ow = override.priority_weights || {};
  for (const key of WEIGHT_KEYS) {
    if (ow[key] != null) merged.priority_weights[key] = num(ow[key], merged.priority_weights[key]);
  }
  return merged;
}

// --- 編集パネル描画(副作用あり) -------------------------------------------

// 企業判断基準パネルを描画する。閾値(注意/危険/停止判断 × 在庫日数/影響供給比率)と
// 優先順位の5重みを編集可能にし、変更を onChange(policy) で通知する。
// 出所(company_policy_name)を「判定基準: ...」として明示する(§11.2)。
export function renderPolicyPanel(containerEl, policy, options) {
  if (!containerEl) return;
  const opts = options || {};
  const p = normalizePolicy(policy);

  const thresholdRows = THRESHOLD_KEYS.map((key) => {
    const t = p.thresholds[key];
    return `
      <div class="policy-threshold-row" data-threshold="${esc(key)}">
        <span class="policy-threshold-label policy-level-${esc(key)}">${esc(THRESHOLD_LABELS[key])}</span>
        <label>最低在庫日数
          <input type="number" min="0" step="1" data-policy-field="min_inventory_days" data-threshold="${esc(key)}" value="${esc(t.min_inventory_days)}">
          <em>日未満</em>
        </label>
        <label>影響供給比率
          <input type="number" min="0" max="100" step="1" data-policy-field="affected_supply_ratio_percent" data-threshold="${esc(key)}" value="${esc(t.affected_supply_ratio_percent)}">
          <em>%以上</em>
        </label>
      </div>`;
  }).join("");

  const weightRows = WEIGHT_KEYS.map((key) => {
    const v = p.priority_weights[key];
    return `
      <div class="policy-weight-row" data-weight="${esc(key)}">
        <span>${esc(WEIGHT_LABELS[key])}</span>
        <input type="range" min="0" max="1" step="0.05" data-policy-weight="${esc(key)}" value="${esc(v)}">
        <b data-weight-value="${esc(key)}">${esc(v.toFixed(2))}</b>
      </div>`;
  }).join("");

  containerEl.innerHTML = `
    <div class="policy-head">
      <span class="policy-kicker">判定基準</span>
      <strong>${esc(p.company_policy_name)}</strong>
      <p class="policy-note">この閾値・重みはデモ企業の設定例です。アプリが定めた正解ではなく、企業のSCMチームが自社方針で設定します。</p>
    </div>
    <section class="policy-section">
      <h4>警戒レベルの閾値</h4>
      <div class="policy-thresholds">${thresholdRows}</div>
    </section>
    <section class="policy-section">
      <h4>製品優先順位の重み</h4>
      <div class="policy-weights">${weightRows}</div>
    </section>
    <div class="policy-actions">
      <button type="button" class="policy-reset" data-policy-action="reset">既定に戻す</button>
    </div>`;

  const notify = () => {
    if (typeof opts.onChange === "function") opts.onChange(readPolicyFromPanel(containerEl, p));
  };

  containerEl.querySelectorAll("[data-policy-field]").forEach((input) => {
    input.addEventListener("input", notify);
  });
  containerEl.querySelectorAll("[data-policy-weight]").forEach((input) => {
    input.addEventListener("input", (event) => {
      const key = event.target.getAttribute("data-policy-weight");
      const out = containerEl.querySelector(`[data-weight-value="${key}"]`);
      if (out) out.textContent = num(event.target.value).toFixed(2);
      notify();
    });
  });
  containerEl.querySelector('[data-policy-action="reset"]')?.addEventListener("click", () => {
    resetPolicy();
    if (typeof opts.onReset === "function") opts.onReset();
  });
}

// パネルの現在入力値からポリシーオブジェクトを読み取る。
function readPolicyFromPanel(containerEl, basePolicy) {
  const out = normalizePolicy(basePolicy);
  containerEl.querySelectorAll("[data-policy-field]").forEach((input) => {
    const field = input.getAttribute("data-policy-field");
    const key = input.getAttribute("data-threshold");
    if (out.thresholds[key] && field) out.thresholds[key][field] = num(input.value, out.thresholds[key][field]);
  });
  containerEl.querySelectorAll("[data-policy-weight]").forEach((input) => {
    const key = input.getAttribute("data-policy-weight");
    if (key in out.priority_weights) out.priority_weights[key] = num(input.value, out.priority_weights[key]);
  });
  return out;
}
