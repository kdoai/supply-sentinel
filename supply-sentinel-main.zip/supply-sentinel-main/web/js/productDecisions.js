// productDecisions.js — シナリオ計算結果 + 企業判断基準 から「製品別の判断」を導出する。
//
// 本ツールの最終アウトプットは、リスクスコアや初動タスクではなく「判断」である:
//   守る製品 / 縮小候補 / 供給配分候補 / 代替材確認が必要な部材 / 在庫積み増し候補 /
//   調達先分散候補 / 生産前倒し候補 / 顧客説明が必要な受注 / 人間承認が必要な判断。
//
// 数値(在庫日数・影響供給比率・金額)はルールベース(propagationEngine)が算出済みで、
// 本モジュールはそれを企業ポリシー(閾値・優先順位の重み)と需要方針に照らして
// 製品ごとの推奨判断(維持/供給配分/縮小/代替材確認/生産前倒し)へ翻訳するだけ。
// 純粋関数: DOM・ネットワーク・乱数・壁時計に触れない(Nodeテストから直接importできる)。

import {
  classifyWarningLevel,
  warningLevelLabel,
  productPriorityScore,
  applyDemandPolicy,
  normalizePolicy,
} from "./companyPolicy.js";

const FULL = 0.999;

// 推奨判断の列挙とラベル。
export const DECISIONS = {
  maintain: "維持",
  allocate: "供給配分",
  reduce: "縮小",
  alt_check: "代替材確認",
  pull_in: "生産前倒し",
};

function asArray(v) {
  return Array.isArray(v) ? v : [];
}
function num(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function nodeMap(network) {
  return new Map(asArray(network?.nodes).map((n) => [n.id, n]));
}
function escapeRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const PRIORITY_FACTOR = { high: 1.0, medium: 0.6, low: 0.3 };

// 承認済み代替材がこの製品に適用できるか(constraints のテキストから判定)。
// 「<製品>...承認」と明記されていれば適用可。「Xのみ承認」で他製品限定なら不可。
// 製品名が出てこない一般的な承認は素材全体に適用可とみなす。
function approvedForProduct(approvedAlts, productName) {
  for (const a of approvedAlts) {
    const c = String(a.constraints || "");
    if (productName && new RegExp(`${escapeRegex(productName)}[^。]{0,10}承認`).test(c)) return true;
    if (/のみ承認/.test(c)) continue; // 特定(他)製品に限定された承認
    if (!/のみ/.test(c)) return true; // 製品限定なしの承認 = 素材全体に適用可
  }
  return false;
}

// 製品に対する代替材の状態: approved(承認済み) / unapproved(要確認) / none(代替なし)。
function altStatusForProduct(alternatives, productName) {
  const alts = asArray(alternatives);
  if (!alts.length) return "none";
  const approvedAlts = alts.filter((a) => a.approved === true);
  if (approvedForProduct(approvedAlts, productName)) return "approved";
  if (approvedAlts.length || alts.some((a) => !a.approved)) return "unapproved";
  return "none";
}

function altAvailabilityFactor(status) {
  if (status === "approved") return 0.2; // 代替が効く=守る優先度は相対的に低い
  if (status === "unapproved") return 0.7;
  return 1.0; // 代替なし=止まりやすい=守る優先度が高い
}

// 製品 → 製造工場ノードを引く(plant/self → product のエッジ)。
function plantOfProduct(network, byId, productId) {
  for (const e of asArray(network.edges)) {
    if (e.target !== productId) continue;
    const src = byId.get(e.source);
    if (src && (src.kind === "plant" || src.kind === "self")) return src;
  }
  return null;
}

// 工場への焦点素材の流入エッジ(1次サプライヤ → 工場)。
function inboundToPlant(network, focal, plantId) {
  return asArray(network.edges).filter(
    (e) => e.target === plantId && e.material === focal,
  );
}

function customerEdgesOfProduct(network, byId, productId) {
  return asArray(network.edges).filter((e) => {
    const t = byId.get(e.target);
    return e.source === productId && t && t.kind === "customer";
  });
}

function inventoryDaysForPlant(inventory, focal, plantName) {
  const row = asArray(inventory).find((r) => r.material === focal && r.plant === plantName);
  if (!row) return null;
  const d = num(row.stock_qty) / num(row.daily_usage, 1);
  return Number.isFinite(d) ? Math.round(d * 10) / 10 : null;
}

/**
 * 製品別の判断と集計バケツを導出する。
 * @param {object} args
 * @param {object} args.network        focal_material 付きの多段ネットワーク
 * @param {object} args.propagation    computeMetrics() の戻り(availability/metrics/node_status)
 * @param {object} args.policy         企業ポリシー(閾値+重み)
 * @param {object} args.controls       シナリオ入力 { altRoute, demand, period, ... }
 * @param {Array}  args.inventory      在庫行
 * @param {Array}  args.alternatives   代替材
 * @returns {{ products:Array, buckets:object, human_approvals:Array, effective_weights:object }}
 */
export function deriveProductDecisions(args = {}) {
  const network = args.network || {};
  const propagation = args.propagation || {};
  const policy = normalizePolicy(args.policy);
  const controls = args.controls || {};
  const inventory = args.inventory || [];
  const alternatives = args.alternatives || [];
  // 供給減少率に連動する在庫耐久係数(既定=1)。製品別在庫日数もKPIと同じ尺度にする。
  const enduranceFactor = Number.isFinite(Number(args.enduranceFactor)) ? Number(args.enduranceFactor) : 1;
  // 対象素材のナフサ依存度(既定=1)。影響供給比率を素材依存度で按分する。
  const exposureFactor = Number.isFinite(Number(args.exposureFactor)) ? Number(args.exposureFactor) : 1;

  const byId = nodeMap(network);
  const focal = network.focal_material;
  const avail = propagation.availability || {};
  const nodeStatus = propagation.node_status || {};
  const metrics = propagation.metrics || {};
  const impactedNames = new Set(asArray(metrics.impacted_products));

  const altRouteAvailable = controls.altRoute !== "none";
  const effectiveWeights = applyDemandPolicy(policy.priority_weights, controls.demand);

  const productNodes = asArray(network.nodes).filter((n) => n.kind === "product");

  // 売上影響の正規化に使う各製品の生の月次受注量。
  const rawRevenue = new Map();
  for (const p of productNodes) {
    const sum = customerEdgesOfProduct(network, byId, p.id).reduce(
      (acc, e) => acc + num(e.monthly_volume),
      0,
    );
    rawRevenue.set(p.id, sum);
  }
  const maxRevenue = Math.max(1, ...rawRevenue.values());

  const products = productNodes.map((p) => {
    const plant = plantOfProduct(network, byId, p.id);
    const plantName = plant?.name || "";
    const inbound = plant ? inboundToPlant(network, focal, plant.id) : [];
    const suppliers = inbound.map((e) => byId.get(e.source)).filter(Boolean);

    const inboundVol = inbound.reduce((acc, e) => acc + num(e.monthly_volume), 0);
    const affectedVol = inbound
      .filter((e) => (avail[e.source] ?? 1) < FULL)
      .reduce((acc, e) => acc + num(e.monthly_volume), 0);
    const plantAffectedRatio = inboundVol > 0 ? Math.round((affectedVol / inboundVol) * 100 * exposureFactor) : 0;

    // 供給集中度(単一サプライヤ依存): 最大シェアの流入比率(0..1)。
    const concentration = inboundVol > 0
      ? Math.max(0, ...inbound.map((e) => num(e.monthly_volume) / inboundVol))
      : (suppliers.length <= 1 ? 1 : 0);
    const singleSupplier = suppliers.length <= 1;

    // 工場に健全(resilient)な流入が残っているか = 生産前倒し/在庫積み増しの余地。
    const hasResilientRoute = inbound.some((e) => {
      const st = nodeStatus[e.source]?.status;
      return st === "resilient" || (avail[e.source] ?? 1) >= FULL;
    });

    const custEdges = customerEdgesOfProduct(network, byId, p.id);
    const priorities = custEdges.map((e) => {
      const t = byId.get(e.target);
      return e.priority || t?.priority || "medium";
    });
    const customerPriority = priorities.includes("high")
      ? "high"
      : priorities.includes("medium")
        ? "medium"
        : priorities.length
          ? "low"
          : "none";
    const customers = custEdges.map((e) => byId.get(e.target)?.name).filter(Boolean);
    const orders = custEdges.map((e) => ({
      order_id: e.order_id || null,
      customer: byId.get(e.target)?.name || "",
      product: p.name,
      monthly_volume: num(e.monthly_volume) || null,
      priority: e.priority || byId.get(e.target)?.priority || "medium",
    }));

    const baseInvDays = inventoryDaysForPlant(inventory, focal, plantName);
    // 供給減少率連動の耐久日数(KPI/最短在庫と同じ尺度)。
    const invDays = baseInvDays == null ? null : Math.max(1, Math.round(baseInvDays * enduranceFactor * 10) / 10);
    const altStatus = altStatusForProduct(alternatives, p.name);
    const impacted = impactedNames.has(p.name) || (avail[p.id] ?? 1) < FULL;
    const warningLevel = impacted ? classifyWarningLevel(invDays, plantAffectedRatio, policy) : "none";

    const factors = {
      customer_priority: PRIORITY_FACTOR[customerPriority] ?? 0,
      revenue_impact: (rawRevenue.get(p.id) || 0) / maxRevenue,
      inventory_days: invDays == null ? 0 : Math.max(0, Math.min(1, 1 - invDays / 30)),
      alternative_availability: altAvailabilityFactor(altStatus),
      single_supplier_dependency: concentration,
    };
    const priorityScore = productPriorityScore(factors, effectiveWeights);

    const decision = recommendDecision({
      impacted,
      customerPriority,
      altStatus,
      warningLevel,
      hasResilientRoute,
      altRouteAvailable,
    });

    const reasons = buildReasons({
      product: p.name,
      decision,
      customerPriority,
      customers,
      invDays,
      warningLevel,
      altStatus,
      plantAffectedRatio,
      hasResilientRoute,
      demand: controls.demand,
    });

    return {
      id: p.id,
      product: p.name,
      material: focal,
      plant: plantName,
      tier: 1,
      suppliers: suppliers.map((s) => ({ name: s.name, tier: s.tier ?? 1 })),
      inventory_days: invDays,
      affected_supply_ratio: plantAffectedRatio,
      revenue_volume: rawRevenue.get(p.id) || 0,
      customer_priority: customerPriority,
      customers,
      orders,
      alt_status: altStatus,
      single_supplier_dependency: singleSupplier,
      concentration: Math.round(concentration * 100),
      has_resilient_route: hasResilientRoute,
      priority_score: priorityScore,
      warning_level: warningLevel,
      warning_label: warningLevelLabel(warningLevel),
      impacted,
      decision,
      decision_label: DECISIONS[decision],
      reasons,
    };
  });

  // 優先順位スコアの降順(高いほど守る優先度が高い)。
  products.sort((a, b) => b.priority_score - a.priority_score);
  products.forEach((p, i) => {
    p.priority_rank = i + 1;
  });

  const buckets = buildBuckets(products, alternatives, policy);
  const human_approvals = buildHumanApprovals(products);

  return { products, buckets, human_approvals, effective_weights: effectiveWeights };
}

function recommendDecision({ impacted, customerPriority, altStatus, warningLevel, hasResilientRoute, altRouteAvailable }) {
  if (!impacted) return "maintain";
  const severe = warningLevel === "stop_or_allocation_decision" || warningLevel === "danger";
  if (customerPriority === "high") {
    // 高優先顧客: 代替材が承認済みなら自信を持って供給配分(守る)。未承認なら先に代替材確認。
    return altStatus === "approved" ? "allocate" : "alt_check";
  }
  if (severe && hasResilientRoute && altRouteAvailable) return "pull_in";
  // 中・低優先顧客で守る対象外 → 縮小候補。
  return "reduce";
}

function buildReasons({ product, decision, customerPriority, customers, invDays, warningLevel, altStatus, plantAffectedRatio, hasResilientRoute, demand }) {
  const cp = { high: "高", medium: "中", low: "低", none: "なし" }[customerPriority] || "中";
  const reasons = [];
  reasons.push(`顧客優先度${cp}${customers.length ? `(${customers.join("・")})` : ""}`);
  if (invDays != null) reasons.push(`在庫${invDays}日(${warningLevelLabel(warningLevel)})`);
  reasons.push(`影響供給比率${plantAffectedRatio}%`);
  if (altStatus === "approved") reasons.push("承認済み代替材あり");
  else if (altStatus === "unapproved") reasons.push("代替材は未承認(要確認)");
  else reasons.push("代替材なし");
  if (hasResilientRoute) reasons.push("健全な調達ルートが残存");
  const demandText = {
    protect_priority_customers: "需要方針=高優先顧客を守る",
    maximize_revenue: "需要方針=売上最大化",
    keep_production: "需要方針=生産継続優先",
    even_allocation: "需要方針=全顧客均等配分",
  }[demand];
  if (demandText) reasons.push(demandText);
  const conclusion = {
    maintain: "→ 現状維持(波及なし)",
    allocate: "→ 優先保護・供給配分対象",
    reduce: "→ 縮小候補",
    alt_check: "→ 代替材の承認状況を確認",
    pull_in: "→ 生産前倒しで吸収",
  }[decision];
  if (conclusion) reasons.push(conclusion);
  return reasons;
}

function buildBuckets(products, alternatives, policy) {
  const impacted = products.filter((p) => p.impacted);
  const protect = products.filter((p) => p.decision === "allocate");
  const reduce = products.filter((p) => p.decision === "reduce");
  const altCheck = products.filter((p) => p.decision === "alt_check" || p.alt_status === "unapproved");
  const pullIn = products.filter((p) => p.decision === "pull_in");

  // 在庫積み増し候補: 影響を受け、かつ健全ルート or 承認済み代替で在庫を厚くできる製品。
  const restock = impacted.filter((p) => p.has_resilient_route || p.alt_status === "approved");
  // 調達先分散候補: 流入が被影響ルートに集中(危険閾値以上)or 単一サプライヤ依存の製品。
  const dangerRatio = policy.thresholds.danger.affected_supply_ratio_percent;
  const diversify = impacted.filter(
    (p) => p.affected_supply_ratio >= dangerRatio || p.single_supplier_dependency,
  );

  // 代替材確認が必要な部材(代替材名リスト)。
  const altMaterials = asArray(alternatives)
    .filter((a) => a.approved !== true || /品質確認|上限|未承認|評価中|限定/.test(String(a.constraints || "")))
    .map((a) => ({ material: a.alternative_material, approved: Boolean(a.approved), constraints: a.constraints || "" }));

  // 顧客説明が必要な受注(影響製品の受注、優先度順)。
  const rank = { high: 0, medium: 1, low: 2 };
  const customerComms = impacted
    .flatMap((p) => p.orders)
    .filter((o) => o.order_id)
    .sort((a, b) => (rank[a.priority] ?? 9) - (rank[b.priority] ?? 9));

  return {
    protect,
    reduce,
    allocate: protect,
    alt_check: altCheck,
    alt_materials: altMaterials,
    restock,
    diversify,
    pull_in: pullIn,
    customer_comms: customerComms,
  };
}

// 人間承認が必要な判断(§16)。AIは起案まで。存在する判断種別に応じて積み上げる。
function buildHumanApprovals(products) {
  const hasImpact = products.some((p) => p.impacted);
  if (!hasImpact) return [];
  const items = new Set();
  // 影響があれば常に必要な実務アクション。
  ["供給配分判断", "発注内容の変更", "サプライヤ切替", "顧客への正式通知", "生産計画の大幅変更"].forEach((x) => items.add(x));
  if (products.some((p) => p.decision === "reduce")) items.add("縮小判断");
  if (products.some((p) => p.decision === "alt_check" || p.alt_status === "unapproved")) items.add("代替材承認プロセス開始");
  return [...items];
}
