import { createMap } from "./map.js";
import { renderPanels } from "./panels.js";
import { createNetwork, networkLegendHtml } from "./network.js";
import { computeMetrics } from "./propagation.js";
import { buildAgentRun, detectInjection } from "./agentTrace.js";
import { createAgentConsole } from "./agentConsole.js";
import { renderDecisionQueue } from "./decisions.js";
import { createScenarioControls } from "./scenarioControls.js";
import {
  loadPolicy,
  savePolicy,
  renderPolicyPanel,
  normalizePolicy,
  DEFAULT_POLICY,
} from "./companyPolicy.js";
import { analyzeTrend } from "./trendAnalysis.js";
import { buildScenarioBrief, renderScenarioBrief } from "./aiScenarioBrief.js";
import { buildScenarioModel, defaultReductionPercentOf, defaultNodeCategoriesOf } from "./scenarioModel.js";
import { requestScenarioResearch, loadSnapshot, saveSnapshot, researchModeLabel } from "./researchClient.js";

const VIEW_TITLES = {
  scenario: "シナリオ設定",
  products: "製品影響・優先順位",
  actions: "打ち手・AI説明",
};

// 対象素材カタログ(指示書§10.1)。専用シナリオを持つ素材はそのネットワークで評価し、
// PP/PE/ABS/その他石化素材は「ナフサ由来素材」としてナフサ供給網で評価し、
// ナフサ依存度(exposure)で影響を差別化する(naphtha 等は exposure=1=不変)。
const MATERIAL_CATALOG = {
  naphtha: { label: "ナフサ", scenarioMaterial: "naphtha", exposure: 1 },
  pp: { label: "PP", scenarioMaterial: "naphtha", exposure: 0.75, derived: true },
  pe: { label: "PE", scenarioMaterial: "naphtha", exposure: 0.65, derived: true },
  abs: { label: "ABS", scenarioMaterial: "naphtha", exposure: 0.55, derived: true },
  "packaging-film": { label: "包装フィルム", scenarioMaterial: "packaging-film", exposure: 1 },
  "semiconductor-adhesive": { label: "半導体接着材", scenarioMaterial: "semiconductor-adhesive", exposure: 1 },
  "other-petrochemical": { label: "その他石化素材", scenarioMaterial: "naphtha", exposure: 0.4, derived: true },
};

let dashboardData = null;
let currentDashboardData = null;
let worldGeojson = null;
let mapInstance = null;
let networkInstance = null;
let mapControlsBound = false;
let activeMaterial = "naphtha";
let scenarioIndex = { scenarios: [] };
let activeScenarioId = "";
let activeScenario = null;
let activeTimeseries = null;
let activeMonthIndex = -1;
let agentMessages = [];
let agentContextKey = "";
let agentChatBound = false;
let agentConsoleInstance = null;
let agentConsoleBound = false;

// シナリオ入力 + 企業判断基準(新主役)。
let scenarioControlsInstance = null;
let companyPolicyBase = DEFAULT_POLICY; // fetch で読み込む正本(company_policy.demo.json)
let currentPolicy = normalizePolicy(DEFAULT_POLICY); // 編集差分を重ねた実効ポリシー
let controlsState = {
  material: "naphtha",
  materialExposure: 1,
  reductionPercent: 30,
  period: 30,
  nodeCategories: ["refinery"],
  altRoute: "partial",
  demand: "protect_priority_customers",
};
let hasRunScenario = false; // 手動「シナリオ実行」が押されたか(=AI調査を走らせたか)
let latestResearchByMaterial = {}; // 実Web調査結果を素材別に保持し、再描画で消さない。

function setLoaderText(message) {
  const el = document.getElementById("boot-loader-text");
  if (el) el.textContent = message;
}

function hideLoader() {
  document.getElementById("boot-loader")?.classList.add("is-hidden");
}

function showFatalError(message) {
  setLoaderText(`読み込みに失敗しました: ${message}`);
  const banner = document.createElement("div");
  banner.setAttribute("role", "alert");
  banner.style.cssText =
    "position:fixed;left:0;right:0;top:0;z-index:9999;" +
    "background:#7f1d1d;color:#fff;padding:12px 16px;font:13px/1.5 system-ui,sans-serif;";
  banner.textContent = `ダッシュボードの読み込みに失敗しました: ${message}`;
  document.body.appendChild(banner);
}

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`GET ${url} -> HTTP ${res.status}`);
  }
  return res.json();
}

function apiBaseUrl() {
  const config = window.SUPPLY_SENTINEL_CONFIG || {};
  return String(config.apiBase || "").replace(/\/$/, "");
}

function agentAdviceUrl() {
  const base = apiBaseUrl();
  return base ? `${base}/api/agent-advice` : "/api/agent-advice";
}

async function fetchDashboardData() {
  const base = apiBaseUrl();
  const apiUrl = base ? `${base}/api/latest-dashboard` : "";
  if (apiUrl) {
    try {
      const payload = await fetchJson(apiUrl);
      if (payload && payload.dashboard) {
        payload.dashboard.meta = payload.dashboard.meta || {};
        payload.dashboard.meta.cloud = {
          served_at: payload.served_at || null,
          state_store: payload.state_store || "api",
          api_base: base,
          persisted: payload.state_store === "cosmos",
        };
        return payload.dashboard;
      }
    } catch (error) {
      console.warn("Cloud dashboard API unavailable; falling back to static demo data.", error);
    }
  }
  const fallback = await fetchJson("./dashboard_data.json");
  fallback.meta = fallback.meta || {};
  fallback.meta.cloud = {
    served_at: null,
    state_store: "static-json",
    api_base: "",
    persisted: false,
  };
  return fallback;
}

function ensureMap() {
  const canvasEl = document.getElementById("world-map");
  if (!canvasEl || !currentDashboardData || !worldGeojson) return;

  if (!mapInstance) {
    mapInstance = createMap(canvasEl, worldGeojson);
    bindMapControls(canvasEl);
    window.addEventListener("resize", () => {
      try {
        mapInstance.resize();
      } catch {
        // Ignore resize races.
      }
    });
  }

  requestAnimationFrame(() => {
    try {
      mapInstance.resize();
      mapInstance.render(currentDashboardData);
    } catch {
      // Ignore resize races.
    }
  });
}

function compactUsdJa(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "0ドル";
  if (Math.abs(n) >= 1_000_000) return `${trim1(n / 1_000_000)}百万ドル`;
  if (Math.abs(n) >= 1_000) return `${trim1(n / 1_000)}千ドル`;
  return `${Math.round(n).toLocaleString("ja-JP")}ドル`;
}

function trim1(num) {
  const s = num.toFixed(1);
  return s.endsWith(".0") ? s.slice(0, -2) : s;
}

function formatDateTime(value) {
  if (!value) return "不明";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return String(value);
  return parsed.toLocaleString("ja-JP", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function routeStatusLabel(status) {
  if (status === "disrupted") return "要対応";
  if (status === "resilient") return "代替可";
  if (status === "exposed") return "監視";
  return "通常";
}

function materialLabel(material) {
  return MATERIAL_CATALOG[material]?.label || material || "不明";
}

function scenarioAssetUrl(file) {
  return `./assets/scenarios/${String(file || "").replace(/^\.\//, "")}`;
}

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

const escAttr = esc;

function asArray(value) {
  return Array.isArray(value) ? value : [];
}

function firstText(items, fallback = "未特定") {
  const value = asArray(items)[0];
  if (!value) return fallback;
  if (typeof value === "string") return value;
  return value.product || value.customer || value.plant || value.name || value.order_id || value.title || fallback;
}

function joinTop(items, picker, fallback = "なし", limit = 3) {
  const values = asArray(items)
    .map((item) => (typeof picker === "function" ? picker(item) : item))
    .filter(Boolean)
    .slice(0, limit);
  return values.length ? values.join("、") : fallback;
}

function agentContextSignature(model) {
  return [
    activeScenarioId,
    activeMonthIndex,
    model?.assessment?.material,
    model?.assessment?.risk_score,
    model?.meta?.ai?.run_id || model?.meta?.cloud?.served_at || model?.meta?.generated_at,
  ].join("|");
}

function buildAgentContext(model) {
  const assessment = model?.assessment || {};
  const metrics = model?.propagation?.metrics || {};
  const ai = model?.meta?.ai || {};
  const cloud = model?.meta?.cloud || {};
  const routes = asArray(model?.route_intel?.routes);
  const affectedRoutes = routes.filter((route) => route.affected);
  const material = materialLabel(assessment.material || activeMaterial);
  const inventoryDays = metrics.inventory_days_min ?? assessment.inventory_days_min ?? "-";
  const affectedShare = metrics.affected_supply_ratio ?? model?.route_intel?.kpis?.affected_share_percent ?? 0;
  const spendAtRisk = metrics.spend_at_risk_usd ?? model?.route_intel?.kpis?.monthly_spend_at_risk ?? 0;
  return {
    material,
    score: assessment.risk_score ?? "-",
    severity: assessment.severity || model?.risk_event?.severity || "unknown",
    inventoryDays,
    affectedShare,
    spendAtRisk,
    products: asArray(assessment.impacted_products),
    customers: asArray(assessment.impacted_customers),
    orders: asArray(assessment.impacted_orders),
    plants: asArray(assessment.impacted_plants),
    actions: asArray(assessment.recommended_actions),
    approvals: asArray(assessment.approval_required),
    evidence: asArray(assessment.evidence).length ? asArray(assessment.evidence) : asArray(model?.risk_event?.evidence),
    alternatives: asArray(assessment.alternatives),
    affectedRoutes,
    ai,
    cloud,
  };
}

function agentStatusLabel(model) {
  const ai = model?.meta?.ai || {};
  const cloud = model?.meta?.cloud || {};
  const mode = ai.run_mode || (cloud.persisted ? "cloud" : "demo");
  const modelName = ai.model || "gpt-5.4-mini";
  const store = cloud.persisted ? "Cosmos保存済み" : "未保存";
  return `${modelName} / ${mode} / ${store}`;
}

function initialAgentMessage(model) {
  const ctx = buildAgentContext(model);
  const route = ctx.affectedRoutes[0];
  const product = firstText(ctx.products, "影響製品なし");
  const customer = firstText(ctx.customers, "影響顧客なし");
  const action = firstText(ctx.actions, "監視継続");
  return `
    <div class="agent-answer-title">初動判断を開始できます</div>
    <div class="agent-trace">
      <span>Risk Watcher</span>
      <span>Impact Mapper</span>
      <span>Response Planner</span>
    </div>
    <p>${esc(ctx.material)}のリスクスコアは <b>${esc(ctx.score)}</b>。影響調達比率は <b>${esc(ctx.affectedShare)}%</b>、最短在庫は <b>${esc(ctx.inventoryDays)}日</b>です。</p>
    <ul>
      <li>要注意ルート: ${esc(route ? `${route.origin?.name || route.supplier} → ${route.plant?.name || "自社工場"}` : "なし")}</li>
      <li>影響候補: ${esc(product)} / ${esc(customer)}</li>
      <li>まずの起案: ${esc(action)}</li>
    </ul>`;
}

// Mirror of the backend classifier: greeting/thanks/meta with no supply-risk
// signal => conversational. A real question always wins.
function isConversationalQuestion(normalized) {
  const q = String(normalized || "").trim();
  if (!q) return false;
  if (/(供給|在庫|代替|切替|切り替|リスク|顧客|取引先|調達|根拠|エビデンス|証拠|初動|対応|対策|納期|遅延|影響|サプライ|発注|価格|割当|配分|生産|出荷|物流|どうす|何をす|なにをす|naphtha|ナフサ|材料|原料)/.test(q)) {
    return false;
  }
  if (/^(hi|hello|hey|yo|hiya|test|ping)\b/.test(q)) return true;
  if (/(こんにち|こんばん|おはよ|はじめま|よろしく|やあ|どうも|ハロー|テスト)/.test(q)) return true;
  if (/(ありがと|thanks|thank you|thx|助かった)/.test(q)) return true;
  if (/((君|あなた|きみ|お前|だれ|誰)は|何ができ|なにができ|使い方|どう使|ヘルプ|help|自己紹介|何者)/.test(q)) return true;
  return false;
}

function makeAgentAnswer(question, model) {
  const ctx = buildAgentContext(model);
  const normalized = String(question || "").toLowerCase();

  // Offline mirror of the backend: greetings / small talk get a light reply,
  // unless the message also carries a supply-risk signal (then analyze).
  if (isConversationalQuestion(normalized)) {
    const material = ctx.material || "供給リスク";
    const reply = /ありがと|thanks|thank you|thx/.test(normalized)
      ? "どういたしまして。供給リスクの初動で気になる点があれば、いつでも相談してください。"
      : `こんにちは。Supply Sentinel の供給リスク相談AIです。現在は ${esc(material)} の供給リスクを監視しています。「まず何をする?」「代替策は?」など、対策の相談をどうぞ。`;
    return `<p>${reply}</p>`;
  }
  const routeText = joinTop(ctx.affectedRoutes, (route) => `${route.supplier || route.origin?.name}→${route.plant?.name || "工場"}`);
  const productText = joinTop(ctx.products, (item) => item.product || item.name || item);
  const customerText = joinTop(ctx.customers, (item) => item.customer || item.name || item);
  const evidenceText = joinTop(ctx.evidence, (item) => item.text || item.claim || item.summary || item, "根拠データなし", 4);
  const approvalText = joinTop(ctx.approvals, (item) => item.action || item.title || item, "承認事項なし");
  const alternativeText = joinTop(ctx.alternatives, (item) => {
    const name = item.alternative_material || item.material || item.name;
    const state = item.approved ? "承認済み" : "要確認";
    return name ? `${name}(${state})` : "";
  });

  let title = "初動プラン";
  let bullets = [
    `${ctx.material}はリスク${ctx.score}、影響調達比率${ctx.affectedShare}%、最短在庫${ctx.inventoryDays}日として扱います。`,
    `最初に確認すべき供給ルートは ${routeText} です。`,
    `調達・生産・営業は、${productText} / ${customerText} への波及を同じ前提で確認します。`,
  ];

  if (normalized.includes("根拠") || normalized.includes("エビデンス") || normalized.includes("なぜ")) {
    title = "判断根拠";
    bullets = [
      `外部原文から抽出した主な根拠は「${evidenceText}」です。`,
      `社内照合では、影響調達比率${ctx.affectedShare}%、最短在庫${ctx.inventoryDays}日、リスク金額${compactUsdJa(ctx.spendAtRisk)}を確認しています。`,
      "AIは確定判断ではなく、根拠と影響範囲をそろえて人の判断を早める役割です。",
    ];
  } else if (normalized.includes("代替") || normalized.includes("切替")) {
    title = "代替策";
    bullets = [
      `代替候補は ${alternativeText} です。`,
      `承認済み候補から先に引当可否を確認し、未承認候補は品質・顧客認定の確認タスクに分けます。`,
      `サプライヤ切替や正式発注変更は ${approvalText} として人の承認に残します。`,
    ];
  } else if (normalized.includes("顧客") || normalized.includes("営業")) {
    title = "顧客影響";
    bullets = [
      `優先して見る顧客は ${customerText} です。`,
      `影響製品は ${productText}。受注一覧では納期が近いものから確認します。`,
      "顧客への正式通知はAIが文案まで準備し、営業責任者が送信判断します。",
    ];
  } else if (normalized.includes("誰") || normalized.includes("まず") || normalized.includes("何")) {
    title = "最初の30分";
    bullets = [
      `調達: ${routeText} の納期・割当率・代替ロット有無をサプライヤに確認します。`,
      `生産管理: ${productText} の在庫${ctx.inventoryDays}日を前提に、止まりやすいラインを確認します。`,
      `営業: ${customerText} への影響可能性を先に把握し、正式連絡は承認後にします。`,
    ];
  }

  return `
    <div class="agent-answer-title">${esc(title)}</div>
    <div class="agent-trace">
      <span>1. 外部シグナル</span>
      <span>2. 在庫/BOM照合</span>
      <span>3. 初動起案</span>
    </div>
    <ul>${bullets.map((item) => `<li>${esc(item)}</li>`).join("")}</ul>
    <p class="agent-footnote">実行判断が必要なもの: ${esc(approvalText)}</p>`;
}

function buildAdviceContext(model) {
  const assessment = model?.assessment || {};
  const metrics = model?.propagation?.metrics || {};
  const kpis = model?.route_intel?.kpis || {};
  const provenance = asArray(model?.provenance).slice(0, 8).map((source) => ({
    kind: source.kind || "source",
    source: source.source || source.label || "",
    claim: source.claim || "",
    url: source.url || "",
    published_at: source.published_at || "",
    origin: source.origin || "",
  }));
  return {
    material: assessment.material || activeMaterial,
    risk_score: metrics.risk_score ?? assessment.risk_score,
    affected_supply_ratio: metrics.affected_supply_ratio ?? kpis.affected_share_percent,
    spend_at_risk_usd: metrics.spend_at_risk_usd ?? kpis.monthly_spend_at_risk,
    inventory_days_min: metrics.inventory_days_min ?? assessment.inventory_days_min,
    impacted_products: asArray(metrics.impacted_products ?? assessment.impacted_products).slice(0, 6),
    impacted_customers: asArray(metrics.impacted_customers ?? assessment.impacted_customers).slice(0, 6),
    recommended_actions: asArray(assessment.recommended_actions).slice(0, 6),
    approval_required: asArray(assessment.approval_required).slice(0, 6),
    evidence: asArray(assessment.evidence).slice(0, 5),
    evidence_sources: provenance,
    run_id: model?.agent_run?.run_id || null,
  };
}

function renderAdviceAnswer(advice) {
  // Conversational replies (greetings / small talk) render as a light bubble —
  // no title, no 3-agent analysis, no cloud/fallback badge (the sender label
  // already reads "Supply Sentinel AI").
  if (advice?.mode === "conversational") {
    return `<p>${esc(advice?.answer || "ご用件をどうぞ。")}</p>`;
  }

  const steps = asArray(advice?.reasoning_steps);
  const evidence = asArray(advice?.evidence).slice(0, 4);
  const actions = asArray(advice?.recommended_actions).slice(0, 4);
  const decisions = asArray(advice?.human_decision_required).slice(0, 4);
  const meta = advice?.meta || {};
  const badge = meta.fallback
    ? `${meta.model || "gpt-5.4-mini"} / fallback`
    : `${meta.model || "gpt-5.4-mini"} / cloud`;
  return `
    <div class="agent-answer-title">AI相談結果 <span class="agent-answer-badge">${esc(badge)}</span></div>
    <p>${esc(advice?.answer || "現在のコンテキストから初動案を整理しました。")}</p>
    ${
      steps.length
        ? `<div class="agent-trace">${steps.map((step) => `<span>${esc(step.agent)}: ${esc(step.result)}</span>`).join("")}</div>`
        : ""
    }
    ${evidence.length ? `<h5>根拠</h5><ul>${evidence.map((item) => `<li>${esc(item)}</li>`).join("")}</ul>` : ""}
    ${actions.length ? `<h5>推奨初動</h5><ul>${actions.map((item) => `<li>${esc(item)}</li>`).join("")}</ul>` : ""}
    ${decisions.length ? `<p class="agent-footnote">人の承認が必要: ${esc(decisions.join("、"))}</p>` : ""}`;
}

function addAgentMessage(role, html) {
  agentMessages.push({ role, html });
  renderAgentPanel(currentDashboardData);
}

function renderAgentPanel(model) {
  const status = document.getElementById("agent-status");
  const thread = document.getElementById("agent-thread");
  const suggestions = document.getElementById("agent-suggestions");
  if (!thread || !suggestions) return;

  if (status) status.textContent = agentStatusLabel(model);
  const key = agentContextSignature(model);
  if (key !== agentContextKey) {
    agentContextKey = key;
    agentMessages = [{ role: "assistant", html: initialAgentMessage(model) }];
  }

  thread.innerHTML = agentMessages
    .map(
      (message) => `
        <article class="agent-message agent-message-${message.role}">
          <span>${message.role === "user" ? "あなた" : "Supply Sentinel AI"}</span>
          <div>${message.html}</div>
        </article>`,
    )
    .join("");
  suggestions.innerHTML = ["まず何をする？", "根拠を見せて", "代替策は？", "顧客影響を要約"]
    .map((text) => `<button type="button" data-agent-question="${esc(text)}">${esc(text)}</button>`)
    .join("");
  thread.scrollTop = thread.scrollHeight;
}

async function fetchAgentAdvice(question, model) {
  const response = await fetch(agentAdviceUrl(), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      question,
      context: buildAdviceContext(model),
    }),
  });
  if (!response.ok) {
    throw new Error(`agent-advice HTTP ${response.status}`);
  }
  return response.json();
}

async function askAgent(question) {
  const trimmed = String(question || "").trim();
  if (!trimmed || !currentDashboardData) return;
  addAgentMessage("user", `<p>${esc(trimmed)}</p>`);
  addAgentMessage("assistant", `<p class="agent-thinking">Azure OpenAI 相談APIへ問い合わせています...</p>`);
  try {
    const advice = await fetchAgentAdvice(trimmed, currentDashboardData);
    agentMessages.pop();
    agentMessages.push({ role: "assistant", html: renderAdviceAnswer(advice) });
    renderAgentPanel(currentDashboardData);
  } catch (error) {
    console.warn("agent-advice unavailable; using local fallback.", error);
    agentMessages.pop();
    agentMessages.push({ role: "assistant", html: makeAgentAnswer(trimmed, currentDashboardData) });
    renderAgentPanel(currentDashboardData);
  }
}

function bindAgentChat() {
  if (agentChatBound) return;
  agentChatBound = true;
  document.getElementById("agent-form")?.addEventListener("submit", (event) => {
    event.preventDefault();
    const input = document.getElementById("agent-input");
    const question = input?.value || "";
    if (input) input.value = "";
    askAgent(question);
  });
  document.getElementById("agent-suggestions")?.addEventListener("click", (event) => {
    const button = event.target.closest?.("[data-agent-question]");
    if (!button) return;
    askAgent(button.getAttribute("data-agent-question"));
  });
}

function ensureAgentConsole() {
  const el = document.getElementById("agent-run-console");
  if (!el) return null;
  if (!agentConsoleInstance) {
    agentConsoleInstance = createAgentConsole(el);
  }
  if (!agentConsoleBound) {
    agentConsoleBound = true;
    el.addEventListener("agent-console-step", (event) => highlightAgentStep(event.detail?.agentKey));
    el.addEventListener("agent-console-done", () => clearAgentStepHighlight());
  }
  return agentConsoleInstance;
}

function updateDecisionSummary(summary) {
  const el = document.getElementById("decision-summary");
  if (!el || !summary) return;
  el.textContent = summary.human
    ? `承認済 ${summary.approved}/${summary.human}・保留 ${summary.hold}・差戻し ${summary.rejected}`
    : "承認不要";
}

function renderAgentRuntime(model) {
  const runConsole = ensureAgentConsole();
  runConsole?.render(model);
  renderDecisionQueue(document.getElementById("approval-list"), model?.agent_run, {
    onChange: updateDecisionSummary,
  });
}

function agentHighlightSelectors(agentKey) {
  const map = {
    orchestrator: [".agent-run-panel", ".summary-panel"],
    risk_scout: [".ai-panel", ".summary-panel"],
    evidence_verifier: [".ai-panel", ".provenance-panel"],
    impact_mapper: [".network-panel", ".inventory-panel", ".orders-panel", ".kpi-panel"],
    response_planner: [".agent-panel", ".response-brief-panel"],
    decision_gate: [".response-brief-panel"],
    reporter: [".response-brief-panel"],
  };
  return map[agentKey] || [];
}

function clearAgentStepHighlight() {
  document.querySelectorAll(".is-agent-active").forEach((el) => el.classList.remove("is-agent-active"));
}

function highlightAgentStep(agentKey) {
  clearAgentStepHighlight();
  for (const selector of agentHighlightSelectors(agentKey)) {
    document.querySelector(selector)?.classList.add("is-agent-active");
  }
}

function bindAgentRuntimeControls() {
  document.getElementById("agent-run-play")?.addEventListener("click", () => {
    setActiveView("actions");
    const runConsole = ensureAgentConsole();
    runConsole?.render(currentDashboardData);
    runConsole?.play({ stepMs: 760 });
  });
}

function renderMapInsight(detail) {
  const el = document.getElementById("map-insight");
  if (!el) return;

  if (!detail) {
    const routes = (((currentDashboardData || {}).route_intel || {}).routes || [])
      .filter((route) => route.material === activeMaterial);
    const affectedShare = routes
      .filter((route) => route.affected)
      .reduce((sum, route) => sum + (Number(route.share_percent) || 0), 0);
    el.innerHTML = `
      <span class="map-insight-kicker">マップ分析</span>
      <strong>${esc(materialLabel(activeMaterial))}供給網の要注意地点</strong>
      <p>赤いルートは割当制限・遅延の可能性がある調達経路です。監視対象を切り替えると、同じ仕組みで他の重要物資も確認できます。</p>
      <dl>
        <div><dt>影響調達比率</dt><dd class="route-risk">${esc(affectedShare)}%</dd></div>
        <div><dt>要対応ルート</dt><dd>${esc(routes.filter((route) => route.affected).length)}件</dd></div>
      </dl>`;
    return;
  }

  if (detail.type === "route" && detail.route) {
    const route = detail.route;
    const status = routeStatusLabel(route.status);
    const riskClass = route.status === "disrupted" ? "route-risk" : "";
    el.innerHTML = `
      <span class="map-insight-kicker">選択中のルート</span>
      <strong>${esc(route.origin?.name)} → ${esc(route.plant?.name)}</strong>
      <p>${esc(route.supplier)} / ${esc(materialLabel(route.material))}。調達比率とリードタイムを見ながら、どの工場に波及するか確認できます。</p>
      <dl>
        <div><dt>状態</dt><dd class="${riskClass}">${esc(status)}</dd></div>
        <div><dt>調達比率</dt><dd>${esc(route.share_percent)}%</dd></div>
        <div><dt>月間調達額</dt><dd>${esc(compactUsdJa(route.monthly_spend_usd))}</dd></div>
        <div><dt>リードタイム</dt><dd>${esc(route.lead_time_days)}日</dd></div>
      </dl>`;
    return;
  }

  if (detail.type === "node" && detail.node) {
    const node = detail.node;
    const related = (((currentDashboardData || {}).route_intel || {}).routes || []).filter((route) => {
      return route.origin?.name === node.label || route.port?.name === node.label || route.plant?.name === node.label;
    });
    const affected = related.filter((route) => route.affected);
    el.innerHTML = `
      <span class="map-insight-kicker">選択中の拠点</span>
      <strong>${esc(node.label)}</strong>
      <p>${esc(node.sublabel || "供給網ノード")}。関連ルートの状態から、自社影響の有無を確認します。</p>
      <dl>
        <div><dt>関連ルート</dt><dd>${esc(related.length)}件</dd></div>
        <div><dt>要対応</dt><dd class="${affected.length ? "route-risk" : ""}">${esc(affected.length)}件</dd></div>
      </dl>`;
  }
}

function clearLinkHighlight() {
  document
    .querySelectorAll(".sourcing-row.is-linked, .kpi-card.is-linked")
    .forEach((el) => el.classList.remove("is-linked"));
}

// Connect a map selection to the business panels: highlight the matching
// 調達構成 row(s) and, for an affected route, the KPI cards it feeds into.
function applyLinkHighlight(detail) {
  clearLinkHighlight();
  if (!detail) return;
  const routes = ((currentDashboardData || {}).route_intel || {}).routes || [];

  let ids = [];
  let affected = false;
  if (detail.type === "route" && detail.route) {
    ids = [detail.route.route_id];
    affected = Boolean(detail.route.affected);
  } else if (detail.type === "node" && detail.node) {
    const label = detail.node.label;
    const related = routes.filter(
      (route) => route.origin?.name === label || route.port?.name === label || route.plant?.name === label,
    );
    ids = related.map((route) => route.route_id);
    affected = related.some((route) => route.affected);
  }

  for (const id of ids) {
    if (!id) continue;
    document.querySelector(`.sourcing-row[data-route-id="${id}"]`)?.classList.add("is-linked");
  }
  if (affected) {
    document
      .querySelectorAll('.kpi-card[data-kpi="affected-share"], .kpi-card[data-kpi="spend"], .kpi-card[data-kpi="routes"]')
      .forEach((el) => el.classList.add("is-linked"));
  }
}

function bindSourcingInteraction() {
  const el = document.getElementById("sourcing-mix");
  if (!el || el.dataset.bound === "1") return;
  el.dataset.bound = "1";

  function selectFromRow(row) {
    const routeId = row.getAttribute("data-route-id");
    if (!routeId) return;
    const route = (((currentDashboardData || {}).route_intel || {}).routes || []).find(
      (item) => item.route_id === routeId,
    );
    if (!route) return;
    mapInstance?.highlightRoute(routeId);
    const detail = { type: "route", route };
    renderMapInsight(detail);
    applyLinkHighlight(detail);
  }

  el.addEventListener("click", (event) => {
    const row = event.target.closest?.(".sourcing-row[data-route-id]");
    if (row) selectFromRow(row);
  });
  el.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const row = event.target.closest?.(".sourcing-row[data-route-id]");
    if (!row) return;
    event.preventDefault();
    selectFromRow(row);
  });
}

function bindMapControls(canvasEl) {
  if (mapControlsBound) return;
  mapControlsBound = true;

  document.getElementById("map-zoom-in")?.addEventListener("click", () => mapInstance?.zoomIn());
  document.getElementById("map-zoom-out")?.addEventListener("click", () => mapInstance?.zoomOut());
  document.getElementById("map-reset")?.addEventListener("click", () => {
    mapInstance?.resetView();
    renderMapInsight(null);
    clearLinkHighlight();
  });
  document.querySelectorAll("[data-map-focus]").forEach((button) => {
    button.addEventListener("click", () => {
      if (button.dataset.mapFocus === "japan") mapInstance?.focusJapan();
      else mapInstance?.focusAsia();
    });
  });
  canvasEl.addEventListener("supply-map-select", (event) => {
    renderMapInsight(event.detail);
    applyLinkHighlight(event.detail);
  });
}

// シナリオに登場する素材の選択肢(ラベル付き、重複排除)。
function materialOptions() {
  // 指示書§10.1 の対象素材を全件提示する(専用シナリオの有無に関わらず選択可能)。
  return Object.entries(MATERIAL_CATALOG).map(([id, entry]) => ({ id, label: entry.label }));
}

function setupScenarioControls() {
  const el = document.getElementById("scenario-controls");
  if (!el) return;
  if (!scenarioControlsInstance) scenarioControlsInstance = createScenarioControls(el);
  refreshScenarioControls();
}

// シナリオ切替時、入力UIをそのシナリオの既定値(供給減少率・被影響ノード)へ更新する。
function refreshScenarioControls() {
  if (!scenarioControlsInstance || !activeScenario) return;
  const exposure = MATERIAL_CATALOG[controlsState.material]?.exposure ?? 1;
  scenarioControlsInstance.render({
    materials: materialOptions(),
    material: controlsState.material,
    materialExposure: exposure,
    derivedMaterial: Boolean(MATERIAL_CATALOG[controlsState.material]?.derived),
    reductionPercent: defaultReductionPercentOf(activeScenario),
    defaultReductionPercent: defaultReductionPercentOf(activeScenario),
    period: controlsState.period,
    nodeCategories: defaultNodeCategoriesOf(activeScenario),
    altRoute: controlsState.altRoute,
    demand: controlsState.demand,
    onChange: onControlsChanged,
    onRun: runScenario,
    onMaterialChange: onMaterialChange,
  });
  controlsState = scenarioControlsInstance.getState();
  controlsState.materialExposure = exposure;
}

// 対象素材の切替。専用シナリオを持つ素材はそのシナリオを、PP/PE/ABS/その他は
// ナフサ供給網を読み込み、ナフサ依存度(exposure)を controlsState に反映する。
async function onMaterialChange(materialId) {
  const entry = MATERIAL_CATALOG[materialId];
  if (!entry) return;
  controlsState.material = materialId;
  controlsState.materialExposure = entry.exposure;
  const scenario = scenarioByMaterial(entry.scenarioMaterial);
  if (scenario && scenario.id !== activeScenarioId) {
    await loadScenario(scenario.id);
  }
  activeMaterial = materialId;
  stopAgentRun();
  mapInstance?.resetView();
  networkInstance?.clear();
  bindScenarioSwitch();
  refreshScenarioControls();
  renderCurrentDashboard();
}

async function selectScenario(id) {
  await loadScenario(id);
  activeMaterial = activeScenario?.material || activeMaterial;
  controlsState.material = activeMaterial;
  controlsState.materialExposure = MATERIAL_CATALOG[activeMaterial]?.exposure ?? 1;
  stopAgentRun();
  mapInstance?.resetView();
  networkInstance?.clear();
  bindScenarioSwitch();
  refreshScenarioControls();
  renderCurrentDashboard();
}

function bindScenarioSwitch() {
  const el = document.getElementById("scenario-switch");
  if (!el) return;
  const items = scenarioIndex.scenarios || [];
  el.innerHTML = items
    .map((item) => {
      const active = item.id === activeScenarioId ? " is-active" : "";
      return `<button type="button" class="scenario-chip${active}" data-scenario-id="${esc(item.id)}">${esc(item.short || item.label)}</button>`;
    })
    .join("");
  el.querySelectorAll("[data-scenario-id]").forEach((button) => {
    button.addEventListener("click", () => {
      const next = button.getAttribute("data-scenario-id");
      if (!next || next === activeScenarioId) return;
      selectScenario(next);
    });
  });
}

async function loadScenario(id) {
  if (!id) return;
  const scenario = await fetchJson(scenarioAssetUrl(`${id}.json`));
  const timeseriesFile = scenario.timeseries_ref
    ? scenario.timeseries_ref.replace(/^\.\//, "")
    : `${id}.timeseries.json`;
  const timeseries = await fetchJson(scenarioAssetUrl(timeseriesFile)).catch(() => ({ scenario_id: id, months: [] }));
  activeScenarioId = id;
  activeScenario = scenario;
  activeTimeseries = timeseries;
  activeMonthIndex = Math.max(0, (timeseries.months || []).length - 1);
}

function scenarioByMaterial(material) {
  return (scenarioIndex.scenarios || []).find((item) => item.material === material) || null;
}

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function periodLabelOf(periodDays) {
  return { 7: "1週間", 14: "2週間", 30: "1か月", 90: "3か月" }[periodDays] || `${periodDays || "-"}日`;
}

function networkColumnOf(node) {
  if (node.kind === "customer") return 4;
  if (node.kind === "product") return 3;
  if (node.kind === "plant" || node.kind === "self") return 2;
  if (node.tier === 1 || node.kind === "port") return 1;
  return 0;
}

function buildFlowFromNetwork(network, propagation) {
  const statusByNode = propagation?.node_status || {};
  const statusByEdge = propagation?.edge_status || {};
  const nodes = (network?.nodes || []).map((node) => ({
    id: node.id,
    stage: networkColumnOf(node),
    label: node.name,
    sublabel: node.makes || node.role_note || node.country || "",
    type: node.kind,
    value: node.priority || node.region || "",
    status: statusByNode[node.id]?.status || "normal",
  }));
  const edges = (network?.edges || []).map((edge) => ({
    source: edge.source,
    target: edge.target,
    value: edge.share_percent || edge.monthly_volume || 20,
    status: statusByEdge[edge.id] || "normal",
  }));
  return { nodes, edges };
}

function networkNodeById(network) {
  return new Map((network?.nodes || []).map((node) => [node.id, node]));
}

function inboundSelfEdges(network) {
  const byId = networkNodeById(network);
  return (network?.edges || []).filter((edge) => {
    const target = byId.get(edge.target);
    return target && (target.kind === "plant" || target.kind === "self") && edge.material === network.focal_material;
  });
}

function buildRoutesFromNetwork(network, propagation, scenario) {
  const byId = networkNodeById(network);
  const edgeStatus = propagation?.edge_status || {};
  return inboundSelfEdges(network).map((edge) => {
    const source = byId.get(edge.source) || {};
    const target = byId.get(edge.target) || {};
    const status = edgeStatus[edge.id] || "normal";
    return {
      route_id: edge.id,
      material: network.focal_material || scenario.material,
      origin: { name: source.name, lat: source.lat, lng: source.lng },
      port: null,
      plant: { name: target.name, lat: target.lat, lng: target.lng },
      region: source.region || target.region || scenario.region,
      supplier: source.name,
      share_percent: edge.share_percent,
      monthly_spend_usd: edge.monthly_spend_usd,
      lead_time_days: edge.lead_time_days,
      transport_mode: edge.transport_mode,
      status,
      baseline_status: "normal",
      affected: status === "disrupted" || status === "exposed",
    };
  });
}

function buildMapNodesFromNetwork(network, propagation) {
  const nodeStatus = propagation?.node_status || {};
  return (network?.nodes || [])
    .filter((node) => Number.isFinite(Number(node.lat)) && Number.isFinite(Number(node.lng)))
    .map((node) => ({
      id: node.id,
      label: node.name,
      sublabel: node.makes || node.role_note || node.country || "",
      lat: Number(node.lat),
      lng: Number(node.lng),
      type: node.kind === "plant" ? "plant" : "supplier",
      affected: nodeStatus[node.id]?.status === "disrupted",
    }));
}

function impactedPlants(network, propagation) {
  const byId = networkNodeById(network);
  const availability = propagation?.availability || {};
  const plantIds = new Set();
  for (const edge of network?.edges || []) {
    const source = byId.get(edge.source);
    const target = byId.get(edge.target);
    if (source?.kind === "plant" && target?.kind === "product" && Number(availability[target.id] ?? 1) < 0.999) {
      plantIds.add(source.name);
    }
  }
  return [...plantIds];
}

function enrichOrders(network, orders) {
  const byId = networkNodeById(network);
  const productToPlant = new Map();
  for (const edge of network?.edges || []) {
    const source = byId.get(edge.source);
    const target = byId.get(edge.target);
    if (source?.kind === "plant" && target?.kind === "product") {
      productToPlant.set(target.name, source.name);
    }
  }
  return asArray(orders).map((order, index) => ({
    order_id: order.order_id || `SO-DEMO-${index + 1}`,
    customer: order.customer,
    product: order.product,
    plant: productToPlant.get(order.product) || "",
    due_date: index === 0 ? "5営業日以内" : "月内",
    quantity: order.quantity,
    priority: order.priority,
  }));
}

function sourceKindLabel(kind) {
  const labels = {
    news: "ニュース",
    supplier_notice: "サプライヤ通知",
    logistics: "物流情報",
    price_feed: "価格情報",
  };
  return labels[kind] || kind || "情報源";
}

function riskTypeFromScenario(scenario) {
  const type = scenario?.disruption?.type;
  if (type === "logistics") return "logistics_delay";
  if (type === "price") return "price_spike";
  if (type === "allocation") return "allocation";
  return type || "supply_delay";
}

function buildAiInputsFromProvenance(sources) {
  return asArray(sources).map((source) => {
    if (source.kind === "supplier_notice") {
      return {
        kind: "supplier",
        supplier: source.source,
        subject: source.label || "サプライヤ通知",
        body: source.claim,
      };
    }
    return {
      kind: "news",
      source: source.source || sourceKindLabel(source.kind),
      headline: source.label || sourceKindLabel(source.kind),
      summary: source.claim,
    };
  });
}

// True when a provenance source carries an injected command in its claim/excerpt.
function isInjectedSource(source) {
  return Boolean(detectInjection(source?.claim) || detectInjection(source?.raw_excerpt));
}

function buildRecommendedActions(scenario, metrics) {
  const material = materialLabel(scenario.material);
  if (!metrics || Number(metrics.risk_score || 0) < 45) return [];
  const actions = [
    `${material}の主要サプライヤへ、次回割当数量・出荷予定・代替ルート余力を確認する。`,
    `在庫${metrics.inventory_days_min ?? "-"}日以内に影響する受注を優先順に並べ替える。`,
    `影響顧客${asArray(metrics.impacted_customers).length}社向けに、説明文案と代替提案を準備する。`,
  ];
  if (Number(metrics.spend_at_risk_usd || 0) > 0) {
    actions.splice(1, 0, `月間${compactUsdJa(metrics.spend_at_risk_usd)}相当の調達影響について、購買・生産管理で初動会議を設定する。`);
  }
  return actions;
}

function buildScenarioOverlayModel(baseModel) {
  if (!activeScenario || !activeScenario.network) return baseModel;
  const scenario = activeScenario;
  const controls = controlsState;
  const policy = currentPolicy;
  const months = asArray(activeTimeseries?.months);
  const month = months[Math.max(0, Math.min(activeMonthIndex, months.length - 1))] || {};

  // シナリオ入力 + 企業判断基準 → 計算済みモデル(純粋コア)。数値はルールベース、AIは作らない。
  const scenarioModel = buildScenarioModel(scenario, controls, policy);
  const { disruption, propagation, metrics, enduranceFactor } = scenarioModel;
  const productDecisions = scenarioModel.decisions;

  // シナリオ根拠は全件を提示(デモ用想定情報)。命令文混入の根拠は検証から除外。
  const sources = asArray(scenario.provenance);
  // Evidence Verifier: external text is observation, not instruction. Any source
  // whose claim/excerpt reads like an injected command is dropped from the
  // *verified* evidence used for scoring/display (it still rides on
  // overlay.provenance so the Agent Run Console can show it was caught).
  const trustedSources = sources.filter((source) => !isInjectedSource(source));
  const evidence = trustedSources.map((source) => `${sourceKindLabel(source.kind)}: ${source.claim}`);
  const routes = buildRoutesFromNetwork(scenario.network, propagation, scenario);
  const affectedRoutes = routes.filter((route) => route.affected);
  const affectedShare = metrics.affected_supply_ratio ?? affectedRoutes.reduce((sum, route) => sum + (Number(route.share_percent) || 0), 0);
  const spendAtRisk = metrics.spend_at_risk_usd ?? affectedRoutes.reduce((sum, route) => sum + (Number(route.monthly_spend_usd) || 0), 0);
  const totalSpend = metrics.total_spend_usd ?? routes.reduce((sum, route) => sum + (Number(route.monthly_spend_usd) || 0), 0);
  // 在庫残日数の表示も供給減少率に連動させる(scenarioModel の耐久係数を反映)。
  const inventory = asArray(scenario.inventory).map((row) => {
    const baseDays = Number(row.stock_qty) / Number(row.daily_usage);
    return {
      ...row,
      days_of_supply: Number.isFinite(baseDays) ? trim1(baseDays * enduranceFactor) : row.days_of_supply,
    };
  });

  // 過去(タイムシリーズ)と現在の差分・トレンド分析(好転/悪化判定)。
  const trend = analyzeTrend(months, Math.max(0, Math.min(activeMonthIndex, months.length - 1)), metrics);

  const overlay = cloneJson(baseModel);
  overlay.meta = overlay.meta || {};
  overlay.meta.scenario = scenario.id;
  overlay.meta.generated_at = month.month ? `${month.month}-28T09:00:00+09:00` : overlay.meta.generated_at;
  // 実際に Cloud API を経由した時だけ cloud 表示。静的デモでは「デモ/ローカル決定論」と明示。
  const persistedCloud = Boolean(overlay.meta?.cloud?.persisted);
  overlay.meta.ai = {
    ...(overlay.meta.ai || {}),
    provider: persistedCloud ? "Azure OpenAI" : "ローカル決定論(デモ)",
    model: overlay.meta.ai?.model || "gpt-5.4-mini",
    model_label: persistedCloud ? "Azure OpenAI · gpt-5.4-mini" : "ローカル決定論(デモ)",
    run_mode: persistedCloud ? "cloud" : "demo",
    inputs: buildAiInputsFromProvenance(sources),
  };
  // 表示用の対象素材(PP/PE/ABS/その他はナフサ由来。ネットワーク自体はナフサ網を使う)。
  const displayMaterial = controls.material || scenario.material;
  overlay.risk_event = {
    ...(overlay.risk_event || {}),
    material: displayMaterial,
    region: scenario.network.nodes?.find((node) => asArray(disruption.hit_nodes).includes(node.id))?.region || "Asia",
    risk_type: riskTypeFromScenario(scenario),
    severity: metrics.event_severity || metrics.severity || "medium",
    confidence: scenario.risk_inputs?.confidence || "medium",
    summary: scenario.headline,
    affected_period: periodLabelOf(controls.period),
    delay_days_min: scenario.disruption?.type === "price" ? null : 5,
    delay_days_max: scenario.disruption?.type === "price" ? null : 14,
    allocation_rate_percent: Math.round((1 - Number(disruption.capacity_drop)) * 100),
    evidence,
  };
  overlay.assessment = {
    ...(overlay.assessment || {}),
    material: displayMaterial,
    alert_id: scenario.id,
    risk_score: metrics.risk_score,
    severity: metrics.severity,
    inventory_days_min: metrics.inventory_days_min,
    evidence,
    scoring_factors: metrics.scoring_factors || {},
    impacted_products: metrics.impacted_products || [],
    impacted_customers: metrics.impacted_customers || [],
    impacted_orders: enrichOrders(scenario.network, metrics.impacted_orders || []),
    impacted_plants: impactedPlants(scenario.network, propagation),
    inventory,
    alternatives: cloneJson(scenario.alternatives || []),
    recommended_actions: buildRecommendedActions(scenario, metrics),
    approval_required: asArray(productDecisions.human_approvals),
    generated_at: overlay.meta.generated_at,
  };
  const focal = {
    material: scenario.material,
    total_share: 100,
    total_spend: totalSpend,
    affected_share: affectedShare,
    affected_spend: spendAtRisk,
    route_count: routes.length,
    affected_count: affectedRoutes.length,
    routes: routes.map((route) => ({
      route_id: route.route_id,
      origin: route.origin?.name,
      region: route.region,
      supplier: route.supplier,
      share_percent: route.share_percent,
      monthly_spend_usd: route.monthly_spend_usd,
      lead_time_days: route.lead_time_days,
      status: route.status,
      affected: route.affected,
    })),
  };
  overlay.route_intel = {
    ...(overlay.route_intel || {}),
    routes,
    map_nodes: buildMapNodesFromNetwork(scenario.network, propagation),
    sourcing: { focal, by_material: { [scenario.material]: focal } },
    kpis: {
      focal_material: scenario.material,
      total_routes: routes.length,
      affected_routes: affectedRoutes.length,
      affected_share_percent: affectedShare,
      total_monthly_spend: totalSpend,
      monthly_spend_at_risk: spendAtRisk,
    },
    flow: buildFlowFromNetwork(scenario.network, propagation),
  };
  overlay.supply_network = {
    focal_material: scenario.material,
    nodes: scenario.network.nodes,
    edges: scenario.network.edges,
    node_status: propagation.node_status,
    edge_status: propagation.edge_status,
  };
  overlay.propagation = propagation;
  overlay.provenance = sources;
  const storedResearch = latestResearchByMaterial[displayMaterial] || null;
  if (storedResearch && storedResearch.mode !== "unavailable" && asArray(storedResearch.evidence).length) {
    const liveProvenance = researchToProvenance(storedResearch);
    overlay.provenance = [...liveProvenance, ...sources];
    overlay.research = storedResearch;
    overlay.meta.evidence_collection = {
      ...(overlay.meta.evidence_collection || {}),
      live_enabled: true,
      live_mode: storedResearch.mode,
      live_fetched_at: storedResearch.fetched_at,
      live_count: asArray(storedResearch.evidence).length,
      live_queries: asArray(storedResearch.queries),
      live_agent_error: storedResearch.error || null,
    };
  }
  overlay.month = month;
  // シナリオ入力・企業判断基準・製品判断・トレンド・AI Scenario Brief を付与。
  overlay.scenario_controls = { ...controls };
  overlay.company_policy = policy;
  overlay.product_decisions = productDecisions;
  overlay.trend = trend;
  overlay.scenario_brief = buildScenarioBrief({
    scenario: { ...scenario, material: displayMaterial },
    metrics,
    policy,
    controls,
    decisions: productDecisions,
    trend,
  });
  // Deterministic multi-agent run trace. trend を渡すと risk_scout に
  // compare_history(過去差分の調査)ツール呼び出しが追加される。
  overlay.agent_run = buildAgentRun(overlay);
  overlay.timeline = months;
  overlay.story = scenario.layperson_story;
  overlay.demo = {
    ...(overlay.demo || {}),
    title: scenario.headline,
    detail: scenario.layperson_story,
    time_label: "現在のシナリオ",
    score_trend: months.map((item) => ({ time_label: item.label, score: item.metrics?.risk_score ?? computeMetrics(scenario.network, item.disruption || {}, {
      inventory: item.inventory || scenario.inventory || [],
      alternatives: scenario.alternatives || [],
      risk_inputs: item.risk_inputs || scenario.risk_inputs || {},
    }).metrics.risk_score })),
    active_events: asArray(scenario.provenance).map((source) => ({
      time_label: "想定",
      title: source.claim,
      source: `${sourceKindLabel(source.kind)} / ${source.source || "デモ用想定"}`,
    })),
    data_sources: asArray(scenario.provenance).map((source) => ({
      name: source.label,
      candidate: source.source,
      status: sourceKindLabel(source.kind),
      freshness: "デモ用想定",
      confidence: source.confidence || "-",
    })),
  };
  return overlay;
}

function renderNetworkSelection(detail) {
  const el = document.getElementById("network-selection");
  if (!el) return;
  if (!detail || !detail.node) {
    el.innerHTML = `
      <span class="network-selection-kicker">選択すると波及を追跡</span>
      <strong>上流ノードをクリックしてください</strong>
      <p>2次サプライヤや原産地を選ぶと、その影響が1次サプライヤ、自社工場、製品、顧客へどう流れるかをハイライトします。</p>`;
    return;
  }
  el.innerHTML = `
    <span class="network-selection-kicker">選択中</span>
    <strong>${esc(detail.node.name)}</strong>
    <p>${esc(detail.node.role_note || detail.node.makes || detail.node.country || "サプライチェーン上のノード")}</p>
    <dl>
      <div><dt>波及製品</dt><dd>${esc(detail.products.join("、") || "なし")}</dd></div>
      <div><dt>影響受注</dt><dd>${esc(detail.orders.length)}件</dd></div>
      <div><dt>月間調達額</dt><dd>${esc(compactUsdJa(detail.spend))}</dd></div>
    </dl>`;
}

function renderNetworkStory(model) {
  const el = document.getElementById("network-story");
  if (!el) return;
  const metrics = model.propagation?.metrics || {};
  const month = model.month || {};
  const scenario = activeScenario || {};
  const material = materialLabel(scenario.material || model.assessment?.material);
  el.innerHTML = `
    <div class="network-story-main">
      <span>${esc(month.label || "現在")} / ${esc(material)}</span>
      <strong>${esc(scenario.headline || model.risk_event?.summary || "供給リスクを監視中")}</strong>
      <p>${esc(scenario.layperson_story || "外部シグナルを自社の製品・顧客影響へ翻訳します。")}</p>
    </div>
    <div class="network-story-kpis">
      <div><span>リスク</span><b>${esc(metrics.risk_score ?? model.assessment?.risk_score ?? "-")}</b></div>
      <div><span>調達影響</span><b>${esc(metrics.affected_supply_ratio ?? 0)}%</b></div>
      <div><span>在庫</span><b>${esc(metrics.inventory_days_min ?? "-")}日</b></div>
      <div><span>金額</span><b>${esc(compactUsdJa(metrics.spend_at_risk_usd ?? 0))}</b></div>
    </div>`;
}

function renderScenarioTimeline(model) {
  const el = document.getElementById("scenario-timeline");
  if (!el) return;
  const months = asArray(model.timeline);
  if (!months.length) {
    el.innerHTML = `<p class="empty">時系列データがありません。</p>`;
    return;
  }
  el.innerHTML = `
    <div class="timeline-bars">
      ${months
        .map((month, index) => {
          const metrics = month.metrics && Object.keys(month.metrics).length ? month.metrics : computeMetrics(activeScenario.network, month.disruption || {}, {
            inventory: month.inventory || activeScenario.inventory || [],
            alternatives: activeScenario.alternatives || [],
            risk_inputs: month.risk_inputs || activeScenario.risk_inputs || {},
          }).metrics;
          const score = Number(metrics.risk_score) || 0;
          const price = Number(month.price_index) || 100;
          const active = index === activeMonthIndex ? " is-active" : "";
          return `
            <button type="button" class="timeline-month${active}" data-month-index="${index}" aria-label="${esc(month.label)}を表示">
              <span>${esc(month.label || month.month)}</span>
              <i style="height:${Math.max(8, Math.min(100, score))}%"></i>
              <b>${esc(score)}</b>
              <em>価格 ${esc(price)}</em>
            </button>`;
        })
        .join("")}
    </div>
    <div class="timeline-events">
      ${asArray(model.month?.events)
        .map((event) => `<div><span>${esc(sourceKindLabel(event.kind))}</span><p>${esc(event.text)}</p></div>`)
        .join("") || `<div><span>監視</span><p>この月は大きなシグナルなし。基準値として利用します。</p></div>`}
    </div>`;
  el.querySelectorAll("[data-month-index]").forEach((button) => {
    button.addEventListener("click", () => {
      activeMonthIndex = Number(button.getAttribute("data-month-index")) || 0;
      stopAgentRun();
      renderCurrentDashboard();
    });
  });
}

function renderProvenance(model) {
  const el = document.getElementById("provenance-list");
  if (!el) return;
  const sources = asArray(model.provenance);
  const research = model.research;
  const hasLive = sources.some((s) => s.live || s.origin === "live_web");
  // ライブ取得がある時は §14.3 準拠で取得日時・更新頻度・実URLを明示。無ければデモ用想定の注記。
  const note = hasLive
    ? `<p class="provenance-note">下段に<strong>ライブ取得</strong>(実ニュース検索)と、デモ用想定情報が混在しています。${
        research && research.fetched_at ? `取得日時: ${esc(formatDateTime(research.fetched_at))} / 更新: 手動「シナリオ実行」時 / 取得元: ${esc(researchModeLabel(research.mode))}。` : ""
      }</p>`
    : `<p class="provenance-note">下記はデモ用のシナリオ根拠(想定情報)です。リアルタイムニュース取得ではありません。参考リンクは、実務でこの種の情報を取得し得る公開ソースの例です。</p>`;
  el.innerHTML = sources.length
    ? note + sources
        .map((source) => {
          const untrusted = source.trust === "untrusted";
          const live = source.live || source.origin === "live_web";
          const tag = live
            ? `<span class="provenance-live-tag">ライブ取得</span>`
            : `<span class="provenance-demo-tag">デモ用想定</span>`;
          const linkLabel = live ? "記事を開く" : "参考リンク";
          const linkText = live
            ? `${source.published_at ? `${esc(formatDateTime(source.published_at))} ・ ` : ""}<a href="${escAttr(source.url)}" target="_blank" rel="noreferrer">${esc(source.source || "記事を開く")}</a>`
            : (source.url
                ? `${linkLabel}: <a href="${escAttr(source.url)}" target="_blank" rel="noreferrer">${esc(source.source || "ソースを開く")}</a>`
                : esc(source.source || "デモ情報源(公開リンクなし)"));
          return `
          <article class="provenance-card${untrusted ? " is-untrusted" : ""}${live ? " is-live" : ""}">
            <div>
              <span>${esc(sourceKindLabel(source.kind))}</span>
              <strong>${esc(source.label || source.source)}</strong>
              ${tag}
            </div>
            <p>${esc(source.claim)}</p>
            <footer>
              <em>${source.url || !live ? linkText : esc(source.source || "")}</em>
              <b>確度 ${esc(source.confidence || "-")}</b>
            </footer>
          </article>`;
        })
        .join("")
    : `<p class="empty">根拠データはありません。</p>`;
}

function renderNetworkPanel(model) {
  const legend = document.getElementById("network-legend");
  if (legend) legend.innerHTML = networkLegendHtml();
  renderNetworkStory(model);
  renderScenarioTimeline(model);
  renderProvenance(model);
  renderNetworkSelection(null);
  const container = document.getElementById("supply-network");
  if (!container) return;
  if (!networkInstance) {
    networkInstance = createNetwork(container);
    container.addEventListener("supply-network-select", (event) => renderNetworkSelection(event.detail));
  }
  networkInstance.render(model);
}

function renderCurrentDashboard() {
  currentDashboardData = buildScenarioOverlayModel(dashboardData);
  renderPanels(currentDashboardData);
  renderNetworkPanel(currentDashboardData);
  renderProductDecisionsPanel(currentDashboardData);
  renderDecisionBucketsPanel(currentDashboardData);
  renderActionsBoardPanel(currentDashboardData);
  renderScenarioBriefPanel(currentDashboardData);
  renderAgentPanel(currentDashboardData);
  renderAgentRuntime(currentDashboardData);
  renderMapInsight(null);
  mapInstance?.highlightRoute(null);
  ensureMap();
}

// scenarioControls の状態に、対象素材のナフサ依存度(exposure)を補完する。
function withExposure(state) {
  return { ...state, materialExposure: MATERIAL_CATALOG[state.material]?.exposure ?? 1 };
}

// 入力(スライダー等)変更時: 即時再計算して反映。AIエージェント実行は走らせない。
function onControlsChanged(state) {
  controlsState = withExposure(state);
  renderCurrentDashboard();
}

// 手動「シナリオ実行」: AIエージェントが実際に公開ニュースを検索・取得し、前回取得との
// 差分から好転/悪化を判定する。バックエンド未接続/取得不可ならデモ差分へフォールバック。
// 自動監視ではなく、人が明示的に実行するトリガー。
async function runScenario(state) {
  controlsState = state ? withExposure(state) : controlsState;
  hasRunScenario = true;
  renderCurrentDashboard();
  setActiveView("actions");
  const runConsole = ensureAgentConsole();
  runConsole?.render(currentDashboardData);
  runConsole?.play({ stepMs: 760 });

  const material = controlsState.material;
  scenarioControlsInstance?.setRunNote("AIエージェントが実ニュースを検索しています…");
  let research = null;
  try {
    research = await requestScenarioResearch({
      apiBase: apiBaseUrl(),
      material,
      materialLabel: materialLabel(material),
      previous: loadSnapshot(material),
    });
  } catch {
    research = null;
  }

  const liveOk = research && research.mode !== "unavailable" && asArray(research.evidence).length > 0;
  if (liveOk) {
    saveSnapshot(material, research.snapshot);
    applyResearchToModel(research);
    const d = research.diff || {};
    scenarioControlsInstance?.setRunNote(
      `実調査完了（${researchModeLabel(research.mode)} / ${asArray(research.evidence).length}件取得）: ${d.headline || ""}`,
    );
  } else {
    const trend = currentDashboardData?.trend;
    const why = research && research.error ? "取得エラー" : "バックエンド未接続";
    scenarioControlsInstance?.setRunNote(
      `ライブ取得不可（${why}）。デモ差分を表示: ${trend?.hasPrevious ? trend.headline : "基準月（比較データなし）"}`,
    );
  }
}

// 実取得した証拠(実URL付き)とライブ差分を現在モデルへ反映し、根拠/情報源/AI Brief を再描画する。
function applyResearchToModel(research) {
  if (!research) return;
  latestResearchByMaterial[research.material] = research;
  renderCurrentDashboard();
}

function researchToProvenance(research) {
  const fetchedAt = research.fetched_at;
  return asArray(research.evidence).map((e, i) => ({
    id: `live-${i}`,
    kind: "news",
    label: "ライブ取得ニュース",
    source: e.source || "公開ニュース",
    claim: e.title,
    url: e.url,
    published_at: e.published_at,
    fetched_at: fetchedAt,
    confidence: e.confidence || "medium",
    origin: "live_web",
    live: true,
    agent_note: e.why || "",
  }));
}

function stopAgentRun() {
  agentConsoleInstance?.stop({ silent: true });
  clearAgentStepHighlight();
}

function trendNewsLabel(outlook) {
  return { improving: "好転(改善)", worsening: "悪化", stable: "横ばい" }[outlook] || "横ばい";
}

// --- 新パネル描画(製品判断 / 判断サマリ / 打ち手 / AI Brief / 企業基準) ----

function decisionClass(decision) {
  return {
    allocate: "dec-allocate",
    reduce: "dec-reduce",
    alt_check: "dec-alt",
    pull_in: "dec-pull",
    maintain: "dec-maintain",
  }[decision] || "dec-maintain";
}

function renderProductDecisionsPanel(model) {
  const el = document.getElementById("product-decisions");
  if (!el) return;
  const products = asArray(model.product_decisions?.products);
  if (!products.length) {
    el.innerHTML = `<p class="empty">製品データがありません。</p>`;
    return;
  }
  const cp = { high: "高", medium: "中", low: "低", none: "なし" };
  const rows = products
    .map((p) => `
      <tr class="${p.impacted ? "is-impacted" : ""}">
        <td class="num">${esc(p.priority_rank)}</td>
        <td><strong>${esc(p.product)}</strong><span class="pd-sub">${esc(p.plant)}</span></td>
        <td>${esc(materialLabel(p.material))}</td>
        <td>${esc(p.suppliers.map((s) => `${s.name}(T${s.tier})`).join("、") || "-")}</td>
        <td class="num ${Number(p.inventory_days) <= 7 ? "text-risk" : ""}">${esc(p.inventory_days ?? "-")}日</td>
        <td class="num">${esc(p.affected_supply_ratio)}%</td>
        <td>${esc(cp[p.customer_priority] || "-")}</td>
        <td>${esc(altStatusLabel(p.alt_status))}</td>
        <td>${p.single_supplier_dependency ? "高" : `${esc(p.concentration)}%`}</td>
        <td><span class="pd-decision ${decisionClass(p.decision)}">${esc(p.decision_label)}</span></td>
        <td class="pd-reasons">${esc(asArray(p.reasons).join(" / "))}</td>
      </tr>`)
    .join("");
  el.innerHTML = `
    <table class="pd-table">
      <thead>
        <tr>
          <th class="num">順位</th><th>製品 / 工場</th><th>影響素材</th><th>影響サプライヤ</th>
          <th class="num">在庫残</th><th class="num">影響供給比率</th><th>顧客優先度</th>
          <th>代替材</th><th>単一依存</th><th>推奨判断</th><th>判断理由</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function altStatusLabel(status) {
  return { approved: "承認済み", unapproved: "要確認", none: "代替なし" }[status] || "-";
}

function bucketList(title, items, picker = (x) => x) {
  const arr = asArray(items).map(picker).filter(Boolean);
  return `
    <div class="bucket-card">
      <span class="bucket-title">${esc(title)} <b>${arr.length}</b></span>
      <ul>${arr.length ? arr.map((x) => `<li>${esc(x)}</li>`).join("") : `<li class="empty">該当なし</li>`}</ul>
    </div>`;
}

function renderDecisionBucketsPanel(model) {
  const el = document.getElementById("decision-buckets");
  if (!el) return;
  const b = model.product_decisions?.buckets || {};
  const name = (p) => p.product;
  el.innerHTML = `
    <div class="bucket-grid">
      ${bucketList("守る製品(供給配分)", b.protect, name)}
      ${bucketList("縮小候補", b.reduce, name)}
      ${bucketList("生産前倒し候補", b.pull_in, name)}
      ${bucketList("在庫積み増し候補", b.restock, name)}
      ${bucketList("調達先分散候補", b.diversify, name)}
      ${bucketList("代替材確認が必要な部材", b.alt_materials, (a) => `${a.material}${a.approved ? "(制約あり)" : "(未承認)"}`)}
    </div>`;
}

function renderActionsBoardPanel(model) {
  const el = document.getElementById("actions-board");
  if (!el) return;
  const b = model.product_decisions?.buckets || {};
  const approvals = asArray(model.product_decisions?.human_approvals);
  const name = (p) => p.product;
  el.innerHTML = `
    <div class="actions-board-grid">
      ${bucketList("守る製品", b.protect, name)}
      ${bucketList("縮小候補", b.reduce, name)}
      ${bucketList("供給配分候補", b.allocate, name)}
      ${bucketList("代替材確認", b.alt_materials, (a) => `${a.material}${a.approved ? "(制約あり)" : "(未承認)"}`)}
      ${bucketList("在庫積み増し", b.restock, name)}
      ${bucketList("調達先分散", b.diversify, name)}
      ${bucketList("生産前倒し", b.pull_in, name)}
      ${bucketList("顧客説明が必要な受注", b.customer_comms, (o) => `${o.order_id || ""} ${o.customer}(${o.product})`)}
      ${bucketList("人間承認が必要な判断", approvals)}
    </div>`;
}

function renderScenarioBriefPanel(model) {
  const el = document.getElementById("ai-scenario-brief");
  if (!el) return;
  renderScenarioBrief(el, model.scenario_brief, { model: model.meta?.ai?.model, research: model.research });
  const status = document.getElementById("brief-status");
  if (status) {
    status.textContent = model.research && model.research.mode !== "unavailable"
      ? `実調査: ${researchModeLabel(model.research.mode)}`
      : model.scenario_brief?.fallback ? "ローカル生成(デモ)" : "cloud";
  }
}

function setActiveView(viewName) {
  if (!VIEW_TITLES[viewName]) {
    viewName = "scenario";
  }
  document.querySelectorAll("[data-view-panel]").forEach((panel) => {
    panel.classList.toggle("is-active", panel.dataset.viewPanel === viewName);
  });
  document.querySelectorAll("[data-view]").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.view === viewName);
  });
  const title = document.getElementById("view-title");
  if (title) title.textContent = VIEW_TITLES[viewName] || viewName;

  if (viewName === "scenario") {
    ensureMap();
  }
}

// 企業判断基準パネル: 閾値・重みの編集 → 保存 → 再計算。
function setupCompanyPolicy() {
  const el = document.getElementById("company-policy");
  if (!el) return;
  renderPolicyPanel(el, currentPolicy, {
    onChange: (policy) => {
      currentPolicy = savePolicy(policy);
      renderCurrentDashboard();
    },
    onReset: () => {
      currentPolicy = normalizePolicy(companyPolicyBase);
      setupCompanyPolicy();
      renderCurrentDashboard();
    },
  });
}

function bindNavigation() {
  document.querySelectorAll("[data-view]").forEach((button) => {
    button.addEventListener("click", () => setActiveView(button.dataset.view));
  });
}

function bindSidebarToggle() {
  const shell = document.getElementById("app-shell");
  const button = document.getElementById("sidebar-toggle");
  if (!shell || !button) return;

  button.addEventListener("click", () => {
    const collapsed = shell.classList.toggle("sidebar-collapsed");
    button.setAttribute("aria-expanded", String(!collapsed));
    button.setAttribute("aria-label", collapsed ? "サイドバーを開く" : "サイドバーを閉じる");
    button.textContent = collapsed ? "›" : "‹";
    ensureMap();
  });
}

function applyInitialSidebarState() {
  const shell = document.getElementById("app-shell");
  const button = document.getElementById("sidebar-toggle");
  if (!shell || !button) return;

  const params = new URLSearchParams(window.location.search);
  if (params.get("sidebar") !== "closed") return;

  shell.classList.add("sidebar-collapsed");
  button.setAttribute("aria-expanded", "false");
  button.setAttribute("aria-label", "サイドバーを開く");
  button.textContent = "›";
}

async function init() {
  setLoaderText("シナリオデータと供給網モデルを読み込んでいます");
  [dashboardData, worldGeojson, companyPolicyBase, scenarioIndex] = await Promise.all([
    fetchDashboardData(),
    fetchJson("./assets/world.geojson"),
    fetchJson("./assets/company_policy.demo.json").catch(() => DEFAULT_POLICY),
    fetchJson("./assets/scenarios/index.json").catch(() => ({ scenarios: [] })),
  ]);
  currentPolicy = loadPolicy(companyPolicyBase);

  setLoaderText("シナリオと多段サプライヤネットワークを準備しています");
  const params = new URLSearchParams(window.location.search);
  const scenarioParam = params.get("scenario");
  const defaultScenario =
    (scenarioParam && (scenarioIndex.scenarios || []).find((item) => item.id === scenarioParam)) ||
    (scenarioIndex.scenarios || []).find((item) => item.default) ||
    (scenarioIndex.scenarios || [])[0];
  if (defaultScenario) {
    await loadScenario(defaultScenario.id);
    activeMaterial = activeScenario?.material || defaultScenario.material || activeMaterial;
  }
  const materialParam = params.get("material");
  const materialScenario = materialParam ? scenarioByMaterial(materialParam) : null;
  if (materialScenario) {
    activeMaterial = materialParam;
    await loadScenario(materialScenario.id);
  }
  const monthParam = params.get("month");
  if (monthParam && activeTimeseries?.months) {
    const index = activeTimeseries.months.findIndex((item) => item.month === monthParam || item.label === monthParam);
    if (index >= 0) activeMonthIndex = index;
  }

  controlsState.material = activeMaterial;
  bindScenarioSwitch();
  setupScenarioControls();
  setupCompanyPolicy();
  bindAgentChat();
  bindAgentRuntimeControls();
  setLoaderText("製品判断とAI Scenario Brief を描画しています");
  renderCurrentDashboard();

  bindNavigation();
  bindSidebarToggle();
  bindSourcingInteraction();
  applyInitialSidebarState();
  const initialView = params.get("view") || "scenario";
  setActiveView(initialView);
  hideLoader();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => init().catch((err) => showFatalError(err.message || err)));
} else {
  init().catch((err) => showFatalError(err.message || err));
}
