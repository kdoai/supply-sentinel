// scenarioModel.js — シナリオ入力(controls)+企業判断基準(policy)から
// 計算済みモデル(propagation / metrics / 製品判断)を組み立てる純粋コア。
//
// app.js(DOM結線)とテスト(Node)の双方から使えるよう、DOM・ネットワーク・
// 壁時計に触れない。数値はすべてルールベース(propagationEngine + scoring)。
//
// 設計の要点:
//   - 供給減少率(%)は capacity_drop と、シナリオ既定値を基準にした深刻度へ写像。
//   - 在庫残日数は減少率連動の「耐久日数」で上書き(既定減少率では基準値に一致)。
//   - そのため既定値ではナフサの固定不変値(65% / 5日 / 82)が再現される。

import { computeMetrics, calculateRiskScore, severityFromScore } from "./propagation.js";
import { nodeCategory, isDisruptableNode } from "./scenarioControls.js";
import { deriveProductDecisions } from "./productDecisions.js";
import { normalizePolicy } from "./companyPolicy.js";

function asArray(v) {
  return Array.isArray(v) ? v : [];
}

export function defaultReductionPercentOf(scenario) {
  const drop = Number(scenario?.disruption?.capacity_drop);
  return Number.isFinite(drop) ? Math.round(drop * 100) : 30;
}

export function defaultNodeCategoriesOf(scenario) {
  const byId = new Map(asArray(scenario?.network?.nodes).map((n) => [n.id, n]));
  const cats = new Set();
  for (const id of asArray(scenario?.disruption?.hit_nodes)) {
    const cat = nodeCategory(byId.get(id));
    if (cat) cats.add(cat);
  }
  return cats.size ? [...cats] : ["refinery"];
}

// 供給減少率を、シナリオ既定の深刻度を基準に上下させる(既定値では既定の深刻度)。
export function severityFromReduction(reductionPercent, defaultReductionPercent, defaultSeverity) {
  const order = ["low", "medium", "high", "critical"];
  const base = Math.max(0, order.indexOf(defaultSeverity || "medium"));
  const shift = Math.round((Number(reductionPercent) - Number(defaultReductionPercent)) / 25);
  const idx = Math.max(0, Math.min(order.length - 1, base + shift));
  return order[idx];
}

// 影響ノード選択 → 被障害ノードID。既定選択ならシナリオ既定の hit_nodes を使い
// (固定デモ不変値を維持)、変更時のみカテゴリからネットワーク全体を走査する。
export function buildDisruptionFromControls(scenario, controls) {
  const defaultCats = defaultNodeCategoriesOf(scenario).slice().sort().join(",");
  const curCats = asArray(controls.nodeCategories).slice().sort().join(",");
  let hitNodes;
  if (curCats === defaultCats) {
    hitNodes = asArray(scenario?.disruption?.hit_nodes);
  } else {
    hitNodes = asArray(scenario?.network?.nodes)
      .filter((n) => isDisruptableNode(n) && controls.nodeCategories.includes(nodeCategory(n)))
      .map((n) => n.id);
  }
  const drop = Math.max(0, Math.min(1, Number(controls.reductionPercent) / 100));
  return { type: scenario?.disruption?.type, hit_nodes: hitNodes, capacity_drop: drop };
}

// 供給減少率下の在庫残日数(耐久)。既定減少率では基準値(=エンジン算出値)に一致し、
// 減少率を上げるほど短く(悪化)、下げるほど長く(改善)なる。
export function enduranceDaysOf(baseInvDays, reductionPercent, defaultReductionPercent) {
  if (baseInvDays == null) return null;
  const r = Math.max(1, Number(reductionPercent));
  const d = Number(baseInvDays) * (Number(defaultReductionPercent) / r);
  return Math.max(1, Math.round(d * 10) / 10);
}

/**
 * シナリオ + 入力 + 企業ポリシー → 計算済みモデル。
 * @returns {{ disruption, derivedSeverity, baseInvDays, enduranceDays, enduranceFactor, propagation, metrics, decisions }}
 */
export function buildScenarioModel(scenario, controls, policy) {
  const pol = normalizePolicy(policy);
  const defaultReduction = defaultReductionPercentOf(scenario);
  const derivedSeverity = severityFromReduction(controls.reductionPercent, defaultReduction, scenario.risk_inputs?.severity);
  const disruption = buildDisruptionFromControls(scenario, controls);

  // 対象素材のナフサ依存度(exposure)。PP/PE/ABS/その他石化素材はナフサ由来として
  // ナフサ供給網で評価し、依存度で影響を差別化する(naphtha 等の専用シナリオは 1=不変)。
  const exposure = Math.max(0.05, Math.min(1, Number(controls.materialExposure ?? 1)));

  const propagation = computeMetrics(scenario.network, disruption, {
    inventory: scenario.inventory || [],
    alternatives: scenario.alternatives || [],
    risk_inputs: { severity: derivedSeverity, confidence: scenario.risk_inputs?.confidence || "medium" },
  });
  const metrics = propagation.metrics;

  // 依存度が低い素材は、ナフサ供給網の影響を相対的に弱く受ける。
  if (exposure < 1) {
    metrics.affected_supply_ratio = Math.round(metrics.affected_supply_ratio * exposure);
    metrics.spend_at_risk_usd = Math.round(metrics.spend_at_risk_usd * exposure);
  }

  const baseInvDays = metrics.inventory_days_min;
  let enduranceDays = enduranceDaysOf(baseInvDays, controls.reductionPercent, defaultReduction);
  // 依存度が低いほど在庫で吸収しやすい(耐久が伸びる)。
  if (enduranceDays != null && exposure < 1) enduranceDays = Math.round((enduranceDays / exposure) * 10) / 10;
  const approvedAlternatives = asArray(scenario.alternatives).filter((a) => a.approved === true);
  const scored = calculateRiskScore({
    riskEvent: { severity: derivedSeverity, confidence: scenario.risk_inputs?.confidence || "medium" },
    inventoryDaysMin: enduranceDays,
    impactedOrders: asArray(metrics.impacted_orders),
    approvedAlternatives,
    affectedSupplyRatio: metrics.affected_supply_ratio,
    spendAtRiskUsd: metrics.spend_at_risk_usd,
  });
  metrics.inventory_days_min = enduranceDays;
  metrics.risk_score = scored.score;
  metrics.severity = severityFromScore(scored.score);
  metrics.scoring_factors = scored.factors;
  metrics.event_severity = derivedSeverity;
  propagation.metrics = metrics;

  const decisions = deriveProductDecisions({
    network: scenario.network,
    propagation,
    policy: pol,
    controls,
    inventory: scenario.inventory || [],
    alternatives: scenario.alternatives || [],
    enduranceFactor: baseInvDays ? enduranceDays / baseInvDays : 1,
    exposureFactor: exposure,
  });

  return {
    disruption,
    derivedSeverity,
    baseInvDays,
    enduranceDays,
    enduranceFactor: baseInvDays ? enduranceDays / baseInvDays : 1,
    propagation,
    metrics,
    decisions,
  };
}
