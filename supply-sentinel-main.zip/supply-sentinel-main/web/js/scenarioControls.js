// scenarioControls.js — シナリオ入力UI(本ツールの主役)。
//
// 川下企業SCMチームが「供給減少シナリオ」を入力するためのコントロール群:
//   対象素材 / 供給減少率(スライダー) / 影響期間 / 影響ノード / 代替ルート可否 / 需要方針
// 値を変えると onChange でアプリへ通知し、影響計算が再実行される。
// 「シナリオ実行」ボタンは手動トリガー: 押すと AI エージェントが走って過去差分を調査する
// (自動監視ではなく、人が明示的に実行する)。
//
// このモジュールは入力状態の保持とUI描画のみを担う(数値計算はしない)。

const PERIOD_OPTIONS = [
  { value: 7, label: "1週間" },
  { value: 14, label: "2週間" },
  { value: 30, label: "1か月" },
  { value: 90, label: "3か月" },
];

const NODE_CATEGORIES = [
  { key: "refinery", label: "製油所" },
  { key: "tier2", label: "Tier2サプライヤー" },
  { key: "tier1", label: "Tier1サプライヤー" },
  { key: "port", label: "港湾" },
  { key: "plant", label: "自社工場" },
];

const ALT_ROUTE_OPTIONS = [
  { value: "available", label: "あり" },
  { value: "partial", label: "一部あり" },
  { value: "none", label: "なし" },
];

const DEMAND_OPTIONS = [
  { value: "protect_priority_customers", label: "高優先顧客を守る" },
  { value: "maximize_revenue", label: "売上最大化" },
  { value: "keep_production", label: "生産継続優先" },
  { value: "even_allocation", label: "全顧客均等配分" },
];

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

// ネットワークのノードを影響ノードのカテゴリへ写像する。
export function nodeCategory(node) {
  if (!node) return null;
  if (node.kind === "refinery") return "refinery";
  if (node.kind === "port") return "port";
  if (node.kind === "plant" || node.kind === "self") return "plant";
  if (node.tier === 2) return "tier2";
  if (node.tier === 1 && node.kind === "supplier") return "tier1";
  return null;
}

// 影響を与え得る(=被障害)ノードか。
export function isDisruptableNode(node) {
  return node && ["refinery", "supplier", "port", "plant", "self"].includes(node.kind);
}

export function createScenarioControls(containerEl) {
  let state = {
    material: "naphtha",
    reductionPercent: 30,
    period: 30,
    nodeCategories: ["refinery"],
    altRoute: "partial",
    demand: "protect_priority_customers",
  };
  let opts = {};

  function getState() {
    return { ...state, nodeCategories: [...state.nodeCategories] };
  }

  // 初期化/シナリオ切替時に呼ぶ。defaults でスライダー初期値やノードの既定選択を設定する。
  function render(nextOpts) {
    opts = nextOpts || {};
    state = {
      material: opts.material ?? state.material,
      reductionPercent: opts.reductionPercent ?? state.reductionPercent,
      period: opts.period ?? state.period,
      nodeCategories: opts.nodeCategories ? [...opts.nodeCategories] : [...state.nodeCategories],
      altRoute: opts.altRoute ?? state.altRoute,
      demand: opts.demand ?? state.demand,
    };
    if (!containerEl) return;

    const materials = Array.isArray(opts.materials) ? opts.materials : [];
    const defaultReduction = opts.defaultReductionPercent ?? state.reductionPercent;

    containerEl.innerHTML = `
      <div class="sc-grid">
        <div class="sc-field sc-field-material">
          <label class="sc-label">対象素材</label>
          <div class="sc-chips" id="sc-materials">
            ${materials.map((m) => `<button type="button" class="sc-chip${m.id === state.material ? " is-active" : ""}" data-sc-material="${esc(m.id)}">${esc(m.label)}</button>`).join("")}
          </div>
          ${opts.derivedMaterial ? `<span class="sc-hint">ナフサ由来素材として、ナフサ供給網で評価（ナフサ依存度 ${Math.round((opts.materialExposure ?? 1) * 100)}%）</span>` : ""}
        </div>

        <div class="sc-field sc-field-reduction">
          <label class="sc-label" for="sc-reduction">供給減少率 <b id="sc-reduction-value">${esc(state.reductionPercent)}%</b></label>
          <input type="range" id="sc-reduction" min="0" max="100" step="5" value="${esc(state.reductionPercent)}">
          <span class="sc-hint">基準(このシナリオの想定)= ${esc(defaultReduction)}%減</span>
        </div>

        <div class="sc-field">
          <label class="sc-label" for="sc-period">影響期間</label>
          <select id="sc-period">
            ${PERIOD_OPTIONS.map((p) => `<option value="${p.value}"${p.value === state.period ? " selected" : ""}>${esc(p.label)}</option>`).join("")}
          </select>
        </div>

        <div class="sc-field">
          <label class="sc-label" for="sc-altroute">代替ルート利用可否</label>
          <select id="sc-altroute">
            ${ALT_ROUTE_OPTIONS.map((a) => `<option value="${a.value}"${a.value === state.altRoute ? " selected" : ""}>${esc(a.label)}</option>`).join("")}
          </select>
        </div>

        <div class="sc-field sc-field-nodes">
          <label class="sc-label">影響ノード</label>
          <div class="sc-checks" id="sc-nodes">
            ${NODE_CATEGORIES.map((n) => `<label class="sc-check"><input type="checkbox" data-sc-node="${esc(n.key)}"${state.nodeCategories.includes(n.key) ? " checked" : ""}>${esc(n.label)}</label>`).join("")}
          </div>
        </div>

        <div class="sc-field sc-field-demand">
          <label class="sc-label" for="sc-demand">需要方針</label>
          <select id="sc-demand">
            ${DEMAND_OPTIONS.map((d) => `<option value="${d.value}"${d.value === state.demand ? " selected" : ""}>${esc(d.label)}</option>`).join("")}
          </select>
        </div>
      </div>

      <div class="sc-run">
        <button type="button" class="sc-run-btn" id="sc-run">シナリオ実行</button>
        <p class="sc-run-note" id="sc-run-note">実行すると、AIエージェントが過去の月次記録と現在の差分を調査し、リスク・ニュースが好転(改善)しているか悪化しているかを判定します。</p>
      </div>`;

    bind();
  }

  function setRunNote(text) {
    const el = containerEl?.querySelector("#sc-run-note");
    if (el) el.textContent = text;
  }

  function notifyChange() {
    if (typeof opts.onChange === "function") opts.onChange(getState());
  }

  function bind() {
    containerEl.querySelectorAll("[data-sc-material]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const next = btn.getAttribute("data-sc-material");
        if (!next || next === state.material) return;
        state.material = next;
        if (typeof opts.onMaterialChange === "function") opts.onMaterialChange(next);
      });
    });

    const reduction = containerEl.querySelector("#sc-reduction");
    reduction?.addEventListener("input", () => {
      state.reductionPercent = Number(reduction.value);
      const out = containerEl.querySelector("#sc-reduction-value");
      if (out) out.textContent = `${state.reductionPercent}%`;
      notifyChange();
    });

    containerEl.querySelector("#sc-period")?.addEventListener("change", (e) => {
      state.period = Number(e.target.value);
      notifyChange();
    });
    containerEl.querySelector("#sc-altroute")?.addEventListener("change", (e) => {
      state.altRoute = e.target.value;
      notifyChange();
    });
    containerEl.querySelector("#sc-demand")?.addEventListener("change", (e) => {
      state.demand = e.target.value;
      notifyChange();
    });
    containerEl.querySelectorAll("[data-sc-node]").forEach((box) => {
      box.addEventListener("change", () => {
        const key = box.getAttribute("data-sc-node");
        const set = new Set(state.nodeCategories);
        if (box.checked) set.add(key);
        else set.delete(key);
        state.nodeCategories = [...set];
        notifyChange();
      });
    });

    containerEl.querySelector("#sc-run")?.addEventListener("click", () => {
      if (typeof opts.onRun === "function") opts.onRun(getState());
    });
  }

  return { render, getState, setRunNote };
}
