// trendAnalysis.js — 過去(タイムシリーズ各月)と現在の差分・トレンド分析。
//
// 手動「シナリオ実行」で AI エージェントが走って "調査" する際の中核ロジック。
// 偽の自動監視ではなく、過去の月次記録(デモシナリオの履歴)と現在の設定を比較し、
// リスク・影響供給比率・在庫日数・金額影響・価格指数が前回比でどちらへ動いたか、
// ニュース/供給状況が「好転(改善)」しているか「悪化」しているかを判定する。
//
// 純粋関数: DOM・ネットワーク・壁時計に触れない。差分はルールベースで計算し、
// AI(aiScenarioBrief)はこの計算済み結果を自然文で説明するだけ(数値は作らない)。

// 各指標の「良い方向」。inventory_days_min だけは増えると改善、他は減ると改善。
const METRIC_DEFS = [
  { key: "risk_score", label: "リスクスコア", goodDirection: "down", unit: "" },
  { key: "affected_supply_ratio", label: "影響供給比率", goodDirection: "down", unit: "%" },
  { key: "inventory_days_min", label: "最短在庫日数", goodDirection: "up", unit: "日" },
  { key: "spend_at_risk_usd", label: "影響金額", goodDirection: "down", unit: "usd" },
  { key: "price_index", label: "価格指数", goodDirection: "down", unit: "" },
];

function num(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

// metrics オブジェクト + month から各指標値を読む(price_index は month 直下にある)。
function readMetric(monthLike, key) {
  if (!monthLike || typeof monthLike !== "object") return null;
  if (key === "price_index") return num(monthLike.price_index ?? monthLike.metrics?.price_index);
  return num((monthLike.metrics || monthLike)[key]);
}

function directionFor(def, from, to) {
  if (from == null || to == null) return "flat";
  const delta = to - from;
  if (delta === 0) return "flat";
  const movedUp = delta > 0;
  const improved = def.goodDirection === "up" ? movedUp : !movedUp;
  return improved ? "improving" : "worsening";
}

// 現在(currentMetrics or months[currentIndex])と、その1つ前の月を比較する。
// months: [{ label, month, price_index, metrics:{...} }]
// currentIndex: 現在として扱う月のindex
// currentMetrics(任意): スライダー操作後のライブ計算値。あれば現在側に優先採用。
export function analyzeTrend(months, currentIndex, currentMetrics) {
  const list = Array.isArray(months) ? months : [];
  const idx = Number.isInteger(currentIndex) ? currentIndex : list.length - 1;
  const prevMonth = idx - 1 >= 0 ? list[idx - 1] : null;
  const curMonth = list[idx] || null;

  if (!prevMonth) {
    return {
      hasPrevious: false,
      overall: "stable",
      news_outlook: "stable",
      headline: "比較できる過去データがありません(基準月)。",
      previous_label: null,
      current_label: curMonth?.label || "現在の設定",
      deltas: [],
      summary_points: ["これは基準となる最初の月のため、前回比のトレンドはまだ判定できません。"],
    };
  }

  // 現在側の値: ライブ計算値があればそれを、無ければ月の metrics を使う。
  const currentSource = currentMetrics && typeof currentMetrics === "object"
    ? { metrics: currentMetrics, price_index: curMonth?.price_index }
    : curMonth;

  const deltas = [];
  let improved = 0;
  let worsened = 0;
  for (const def of METRIC_DEFS) {
    const from = readMetric(prevMonth, def.key);
    const to = readMetric(currentSource, def.key);
    if (from == null || to == null) continue;
    const direction = directionFor(def, from, to);
    if (direction === "improving") improved += 1;
    else if (direction === "worsening") worsened += 1;
    deltas.push({
      key: def.key,
      label: def.label,
      unit: def.unit,
      from,
      to,
      delta: Math.round((to - from) * 1000) / 1000,
      direction,
    });
  }

  // 総合判定はリスクスコア(=複合指標)を重視し、在庫・影響供給比率を補助に置く。
  // 影響供給比率/金額/価格は調達構成側の指標で、減少率スライダー単体では動かないため
  // 同列に数えると見出しと矛盾しうる。リスク2:在庫1:比率1 で重み付けする。
  const dirOf = (key) => deltas.find((d) => d.key === key)?.direction;
  const overallWeights = { risk_score: 2, inventory_days_min: 1, affected_supply_ratio: 1 };
  let weighted = 0;
  for (const [key, w] of Object.entries(overallWeights)) {
    const dir = dirOf(key);
    if (dir === "improving") weighted += w;
    else if (dir === "worsening") weighted -= w;
  }
  const overall = weighted > 0 ? "improving" : weighted < 0 ? "worsening" : (worsened > improved ? "worsening" : improved > worsened ? "improving" : "stable");

  // ニュース見通し: リスクスコア・価格指数の動きを重視して判定する
  // (ユーザー要望「ニュースが好転しているかどうか」)。
  const risk = deltas.find((d) => d.key === "risk_score");
  const price = deltas.find((d) => d.key === "price_index");
  const newsScore =
    (risk ? signFor(risk.direction) : 0) * 2 + (price ? signFor(price.direction) : 0);
  const news_outlook = newsScore > 0 ? "improving" : newsScore < 0 ? "worsening" : "stable";

  const headline = buildHeadline(overall, deltas, prevMonth, currentSource);
  const summary_points = buildSummaryPoints(deltas, news_outlook);

  return {
    hasPrevious: true,
    overall,
    news_outlook,
    headline,
    previous_label: prevMonth.label || prevMonth.month || "前回",
    current_label: curMonth?.label || "現在の設定",
    deltas,
    summary_points,
  };
}

function signFor(direction) {
  if (direction === "improving") return 1;
  if (direction === "worsening") return -1;
  return 0;
}

export function trendLabel(direction) {
  return { improving: "好転(改善)", worsening: "悪化", stable: "横ばい", flat: "横ばい" }[direction] || "横ばい";
}

function formatValue(def, value) {
  if (value == null) return "-";
  if (def.key === "spend_at_risk_usd" || def.unit === "usd") return compactUsdJa(value);
  return `${value}${def.unit || ""}`;
}

function buildHeadline(overall, deltas, prevMonth, currentSource) {
  const prevLabel = prevMonth.label || prevMonth.month || "前回";
  const bits = [];
  const risk = deltas.find((d) => d.key === "risk_score");
  const inv = deltas.find((d) => d.key === "inventory_days_min");
  if (risk && risk.delta !== 0) bits.push(`リスク${risk.delta > 0 ? "+" : ""}${risk.delta}`);
  if (inv && inv.delta !== 0) bits.push(`在庫${inv.delta > 0 ? "+" : ""}${inv.delta}日`);
  const trend = { worsening: "悪化傾向", improving: "好転(改善)傾向", stable: "横ばい" }[overall];
  return bits.length
    ? `${prevLabel}比で供給状況は${trend}（${bits.join("・")}）。`
    : `${prevLabel}比で供給状況は${trend}。`;
}

function buildSummaryPoints(deltas, newsOutlook) {
  const defByKey = Object.fromEntries(METRIC_DEFS.map((d) => [d.key, d]));
  const points = deltas
    .filter((d) => d.direction !== "flat")
    .map((d) => {
      const def = defByKey[d.key];
      const arrow = d.direction === "improving" ? "改善" : "悪化";
      return `${d.label}: ${formatValue(def, d.from)} → ${formatValue(def, d.to)}（${arrow}）`;
    });
  const newsText = {
    improving: "ニュース・供給状況は前回比で好転(改善)の兆し。",
    worsening: "ニュース・供給状況は前回比で悪化しており、好転の兆しは見られない。",
    stable: "ニュース・供給状況は前回比で大きな変化なし(横ばい)。",
  }[newsOutlook];
  points.unshift(newsText);
  return points;
}

// 桁圧縮(百万ドル/千ドル)。他モジュールと同じ表記。
function compactUsdJa(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "0ドル";
  if (Math.abs(n) >= 1_000_000) return `${trim1(n / 1_000_000)}百万ドル`;
  if (Math.abs(n) >= 1_000) return `${trim1(n / 1_000)}千ドル`;
  return `${Math.round(n).toLocaleString("ja-JP")}ドル`;
}

function trim1(n) {
  const s = n.toFixed(1);
  return s.endsWith(".0") ? s.slice(0, -2) : s;
}
