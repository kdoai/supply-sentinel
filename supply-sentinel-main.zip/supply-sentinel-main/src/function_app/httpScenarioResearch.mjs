// httpScenarioResearch.mjs — 「シナリオ実行」から呼ばれる実Web調査エンドポイント。
//
// フロントの手動「シナリオ実行」が叩く唯一のHTTPシーム。対象素材について実際に
// 公開ニュースを検索・取得し、前回スナップショットとの差分から好転/悪化を判定する。
//
// 自律度の段階(researchAgent と同じ境界):
//   - Azure OpenAI 設定済み + cloud モード → LLM が自分でクエリを決めて search_news
//     ツールを呼び、実RSSを検索して URL 接地した証拠を返す(真の自律検索)。
//   - 未設定/失敗時 → 素材から組み立てたクエリで Google News RSS を直接検索(実取得・キー不要)。
//   - ネットワーク不通など全失敗時 → mode:"unavailable"(フロントはデモ差分へフォールバック)。
//
// 防御: 入力検証、never-throw(全失敗でも 200 で unavailable を返す)、外部記事は
// データであって命令ではない(researchAgent 側で injection 対策済み)。

import { resolveRunMode, azureOpenAiConfig } from "../supply_sentinel/config.mjs";
import { runResearchAgent } from "../supply_sentinel/researchAgent.mjs";
import { searchNewsQuery } from "../supply_sentinel/liveEvidence.mjs";
import { summarizeEvidence, diffResearch } from "../supply_sentinel/researchDiff.mjs";

const MAX_EVIDENCE = 6;
const RATE_LIMIT_WINDOW_MS = 60_000;
const DEFAULT_RATE_LIMIT_PER_MINUTE = 12;
const rateBuckets = new Map();

// 素材 → 英語検索語(Google News は en-US)。逼迫系のORを付与する。
const MATERIAL_QUERY = {
  naphtha: "naphtha",
  pp: "polypropylene",
  pe: "polyethylene",
  abs: "ABS resin",
  "packaging-film": "packaging film BOPP",
  "semiconductor-adhesive": "semiconductor adhesive material",
  "other-petrochemical": "petrochemical feedstock",
};

function stringOr(value, fallback) {
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

function azureConfiguredFrom(config) {
  return Boolean(config && config.endpoint && config.deployment && (config.useAad || config.apiKey));
}

function buildQuery(material) {
  const term = MATERIAL_QUERY[material] || material || "petrochemical";
  return `${term} supply shortage OR refinery OR allocation OR disruption OR delay`;
}

function provenanceToEvidence(provenance, material) {
  return (Array.isArray(provenance) ? provenance : []).slice(0, MAX_EVIDENCE).map((p) => ({
    title: p.claim || p.headline || "",
    url: p.url || "",
    source: p.source || p.label || "",
    published_at: p.published_at || null,
    why: p.agent_note || "",
    material: p.material || material,
    confidence: p.confidence || "medium",
  })).filter((e) => e.title);
}

/**
 * 実Web調査を実行し、証拠 + 前回比の差分を返す。never-throw。
 * @param {{material?:string, materialLabel?:string, previous?:object}} input
 * @param {{fetchImpl?:Function, mode?:string, config?:object, runAgent?:Function, searchFn?:Function, now?:Date}} deps
 */
export async function scenarioResearch(input = {}, deps = {}) {
  const material = stringOr(input.material, "naphtha");
  const materialLabel = stringOr(input.materialLabel, material);
  const previous = input && input.previous && typeof input.previous === "object" ? input.previous : null;

  const fetchImpl = deps.fetchImpl || globalThis.fetch;
  const mode = deps.mode || resolveRunMode();
  const config = deps.config || azureOpenAiConfig();
  const runAgent = deps.runAgent || runResearchAgent;
  const searchFn = deps.searchFn || searchNewsQuery;
  const now = deps.now || new Date();
  const fetchedAt = now.toISOString();

  let evidence = [];
  let queries = [];
  let agentLog = [];
  let usedMode = "unavailable";
  let error = null;

  const cloud = (mode === "azure" || mode === "cloud") && azureConfiguredFrom(config);
  try {
    if (cloud) {
      // LLM 自律検索: モデルがクエリを決め、search_news で実RSSを叩いて接地する。
      const r = await runAgent({ materials: [materialLabel], enabled: true, fetchImpl, now, mode, config });
      evidence = provenanceToEvidence(r.provenance, material);
      queries = Array.isArray(r.queries) ? r.queries : [];
      agentLog = Array.isArray(r.agent_log) ? r.agent_log : [];
      usedMode = r.mode === "agent" ? "agent" : "rss"; // agent path or its rss fallback
    } else {
      // キー無し: 素材クエリで Google News RSS を直接検索(実取得)。
      const query = buildQuery(material);
      queries = [query];
      const found = await searchFn(query, { fetchImpl, fetchedAt, maxItems: MAX_EVIDENCE, material });
      evidence = provenanceToEvidence(found.provenance, material);
      usedMode = "rss";
    }
  } catch (err) {
    error = err && err.message ? err.message : String(err);
    usedMode = "unavailable";
    evidence = [];
  }

  const snapshot = summarizeEvidence(evidence, material);
  const diff = diffResearch(previous, snapshot);

  return {
    mode: usedMode,
    fetched_at: fetchedAt,
    material,
    material_label: materialLabel,
    queries,
    agent_log: agentLog,
    evidence,
    snapshot,
    diff,
    error,
  };
}

// --- Azure Functions v4 HTTP ハンドラ(クラウド配備時の対称性のため) ---------

export async function scenarioResearchHandler(request, context) {
  const corsHeaders = {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "access-control-allow-origin": process.env.AGENT_ADVICE_ALLOW_ORIGIN || "*",
    "access-control-allow-methods": "POST,OPTIONS",
    "access-control-allow-headers": "content-type",
  };
  if (request.method === "OPTIONS") return { status: 204, headers: corsHeaders };

  const rate = checkRateLimit(request);
  if (!rate.allowed) {
    return {
      status: 429,
      headers: { ...corsHeaders, "retry-after": String(rate.retryAfterSeconds) },
      body: JSON.stringify({
        mode: "unavailable",
        evidence: [],
        error: "rate_limited",
        message: "実Web調査APIの呼び出しが短時間に集中しています。少し待ってから再実行してください。",
      }),
    };
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return { status: 400, headers: corsHeaders, body: JSON.stringify({ error: "invalid_json" }) };
  }
  try {
    const result = await scenarioResearch(body || {});
    return { status: 200, headers: corsHeaders, body: JSON.stringify(result) };
  } catch (error) {
    if (context && context.error) context.error("[scenarioResearchHandler] unexpected", error);
    // never-throw 契約: それでも失敗したら unavailable を返す。
    return {
      status: 200,
      headers: corsHeaders,
      body: JSON.stringify({ mode: "unavailable", evidence: [], diff: diffResearch(null, summarizeEvidence([], "")), error: String(error) }),
    };
  }
}

function checkRateLimit(request) {
  const limit = Number(process.env.SCENARIO_RESEARCH_RATE_LIMIT_PER_MINUTE || DEFAULT_RATE_LIMIT_PER_MINUTE);
  if (!Number.isFinite(limit) || limit <= 0) return { allowed: true, retryAfterSeconds: 0 };
  const now = Date.now();
  const key = clientKey(request);
  const bucket = rateBuckets.get(key);
  if (!bucket || now - bucket.windowStart >= RATE_LIMIT_WINDOW_MS) {
    rateBuckets.set(key, { windowStart: now, count: 1 });
    return { allowed: true, retryAfterSeconds: 0 };
  }
  if (bucket.count >= limit) {
    return {
      allowed: false,
      retryAfterSeconds: Math.max(1, Math.ceil((RATE_LIMIT_WINDOW_MS - (now - bucket.windowStart)) / 1000)),
    };
  }
  bucket.count += 1;
  return { allowed: true, retryAfterSeconds: 0 };
}

function clientKey(request) {
  const forwarded = headerValue(request, "x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim().slice(0, 80) || "anonymous";
  const clientIp = headerValue(request, "x-client-ip");
  if (clientIp) return clientIp.slice(0, 80);
  return "anonymous";
}

function headerValue(request, name) {
  const headers = request && request.headers;
  if (!headers) return "";
  if (typeof headers.get === "function") return headers.get(name) || headers.get(name.toLowerCase()) || "";
  return headers[name] || headers[name.toLowerCase()] || "";
}
