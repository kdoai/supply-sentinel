const RISK_TYPE_PATTERNS = [
  ["shutdown", /shutdown|shut\s*down|停止|操業停止|halt|force majeure|不可抗力/i],
  ["allocation", /allocation|allocat|割当|割り当て|供給制限|配分|数量制限/i],
  ["supply_delay", /delay|delayed|late|postpone|遅延|納期|後ろ倒し|出荷遅れ/i],
  ["logistics_delay", /vessel|logistics|congestion|port|物流|船|港湾|混雑|航空貨物/i],
  ["price_spike", /price|価格|急騰|高騰|spike|surge|soar/i],
];

const SOURCE_RELIABILITY = {
  supplier_notice: 3,
  supplier: 3,
  official: 3,
  news: 2,
  price_feed: 2,
  logistics: 2,
  sns: 0,
  social: 0,
};

export function extractRiskEvent({ newsEvents = [], supplierNotices = [], materials = [] }) {
  const news = newsEvents[0] ?? {};
  const notice = supplierNotices[0] ?? {};
  const combinedText = [
    news.headline,
    news.summary,
    notice.subject,
    notice.body,
  ]
    .filter(Boolean)
    .join("\n");

  const material =
    normalizeMaterial(notice.body, materials) ??
    normalizeMaterial(combinedText, materials) ??
    normalizeMaterial(news.material, materials) ??
    "unknown";
  const delay = extractDelayDays(combinedText);
  const allocationRate = extractAllocationRate(combinedText);
  const riskType = detectRiskType(combinedText);
  const severity = determineSeverity({ news, delay, allocationRate, riskType, text: combinedText });
  const confidence = determineConfidence({ news, notice, delay, allocationRate, riskType, text: combinedText });

  return {
    material,
    risk_type: riskType,
    region: news.region ?? null,
    affected_period: extractAffectedPeriod(combinedText) ?? (riskType === "unknown" ? null : "next 2-3 weeks"),
    delay_days_min: delay.min,
    delay_days_max: delay.max,
    allocation_rate_percent: allocationRate,
    severity,
    confidence,
    evidence: buildEvidence({ news, notice, delay, allocationRate, confidence }),
    summary: buildSummary({ material, delay, allocationRate, riskType }),
    sources: {
      news_id: news.id ?? null,
      supplier_notice_id: notice.id ?? null,
    },
  };
}

export function normalizeMaterial(text = "", materials = []) {
  const value = String(text || "").toLowerCase();
  if (!value) return null;

  for (const material of Array.isArray(materials) ? materials : []) {
    const aliases = [material.material_id, material.display_name, ...(Array.isArray(material.aliases) ? material.aliases : [])]
      .filter(Boolean)
      .map((alias) => String(alias).toLowerCase());
    if (aliases.some((alias) => alias && value.includes(alias))) {
      return material.material_id;
    }
  }

  if (/(naphtha|ナフサ|ナフサ由来)/i.test(value)) return "naphtha";
  if (/(polypropylene|\bpp\b|ポリプロピレン)/i.test(value)) return "pp";
  if (/(polyethylene|\bpe\b|ポリエチレン)/i.test(value)) return "pe";
  if (/(abs resin|\babs\b|abs樹脂)/i.test(value)) return "abs";
  if (/(packaging|film|包装フィルム|bopp)/i.test(value)) return "packaging-film";
  if (/(adhesive|接着材|半導体接着)/i.test(value)) return "semiconductor-adhesive";
  if (/(petrochemical|石化|石油化学)/i.test(value)) return "other-petrochemical";
  return null;
}

function detectRiskType(text) {
  const matchedTypes = RISK_TYPE_PATTERNS
    .filter(([, pattern]) => pattern.test(text))
    .map(([type]) => type);

  if (matchedTypes.includes("shutdown")) return "shutdown";
  if (matchedTypes.includes("allocation")) return "allocation";
  if (matchedTypes.includes("supply_delay")) return "supply_delay";
  return matchedTypes[0] ?? "unknown";
}

function extractDelayDays(text) {
  const value = String(text || "");
  const range = value.match(/(\d+(?:\.\d+)?)\s*(?:to|[-–—~〜～]|から)\s*(\d+(?:\.\d+)?)\s*(?:business\s*)?(?:days?|日|営業日)/i);
  if (range) {
    return { min: Number(range[1]), max: Number(range[2]) };
  }
  const single = value.match(/(\d+(?:\.\d+)?)\s*(?:business\s*)?(?:days?|日|営業日)(?:\s*(?:delay|遅延|遅れ|後ろ倒し))?/i);
  if (single) {
    const days = Number(single[1]);
    return { min: days, max: days };
  }
  return { min: null, max: null };
}

function extractAllocationRate(text) {
  const value = String(text || "");
  const percent = value.match(/(?:allocation|allocat|割当|割り当て|配分|通常|normal|contract)[^0-9０-９]{0,24}(\d+(?:\.\d+)?)\s*[％%]/i) ||
    value.match(/(\d+(?:\.\d+)?)\s*[％%]\s*(?:of\s+normal|normal|通常|割当|割り当て|配分)/i);
  if (percent) return Number(percent[1]);

  const wari = value.match(/([1-9１-９])\s*割/);
  if (wari) return Number(toAsciiDigit(wari[1])) * 10;

  const decimal = value.match(/0\.(\d+)\s*(?:of\s+normal|通常|割当|配分)/i);
  if (decimal) return Math.round(Number(`0.${decimal[1]}`) * 100);

  return null;
}

function extractAffectedPeriod(text) {
  const value = String(text || "");
  const en = value.match(/next\s+([a-z0-9\s-]+?weeks?)/i);
  if (en) return `next ${en[1].trim()}`;
  const ja = value.match(/(?:今後|次回|向こう)\s*([0-9０-９]+)\s*(週間|週|か月|ヶ月|日間)/);
  if (ja) return `${ja[0]}`;
  return null;
}

function determineSeverity({ news, delay, allocationRate, riskType, text }) {
  if (riskType === "shutdown") return "critical";
  if (allocationRate != null && allocationRate <= 60) return "critical";
  if (allocationRate != null && allocationRate <= 75) return "high";
  if (delay.max != null && delay.max >= 7) return "high";
  if (riskType === "logistics_delay" && /space|困難|混雑|遅延拡大/i.test(text)) return "high";
  if (riskType === "allocation" && allocationRate == null) return "medium";
  if (delay.max != null && delay.max > 0) return "medium";
  if (news.severity_hint === "high") return "high";
  if (riskType !== "unknown") return "low";
  return "low";
}

function determineConfidence({ news, notice, delay, allocationRate, riskType, text }) {
  const reliability = Math.max(sourceReliability(news), notice.body ? 3 : 0);
  const explicitSignals = [
    delay.max != null,
    allocationRate != null,
    /received_at|published_at|next|今後|次回|通常|normal|出荷|shipment/i.test(text),
    riskType !== "unknown",
  ].filter(Boolean).length;

  if (/未検証|rumor|unconfirmed|sns|掲示板/i.test(text) || reliability === 0) return "low";
  if (reliability >= 3 && explicitSignals >= 3) return "high";
  if (reliability >= 2 && explicitSignals >= 2) return "medium";
  return "low";
}

function sourceReliability(source) {
  const kind = String(source.kind || source.type || (source.live ? "news" : "news")).toLowerCase();
  const sourceName = String(source.source || "").toLowerCase();
  if (/sns|social|掲示板/.test(kind) || /sns|social|掲示板/.test(sourceName)) return 0;
  return SOURCE_RELIABILITY[kind] ?? 2;
}

function buildEvidence({ news, notice, delay, allocationRate, confidence }) {
  const evidence = [];
  if (news.headline) evidence.push(`News headline: ${news.headline}`);
  if (delay.max != null) evidence.push(`Supplier/news text indicates ${delay.min}-${delay.max} day shipment delay.`);
  if (allocationRate != null) evidence.push(`Supplier/news text indicates allocation may be limited to ${allocationRate}% of normal volume.`);
  if (notice.subject) evidence.push(`Supplier notice subject: ${notice.subject}`);
  evidence.push(`Confidence judged as ${confidence} from source reliability and explicit numeric/date signals.`);
  return evidence;
}

function buildSummary({ material, delay, allocationRate, riskType }) {
  const parts = [`${material} ${riskType === "unknown" ? "monitoring signal" : "supply risk detected"}`];
  if (delay.max != null) parts.push(`expected delay ${delay.min}-${delay.max} days`);
  if (allocationRate != null) parts.push(`allocation may be ${allocationRate}% of normal volume`);
  return `${parts.join("; ")}.`;
}

function toAsciiDigit(value) {
  return String(value).replace(/[０-９]/g, (d) => String(d.charCodeAt(0) - 0xff10));
}
