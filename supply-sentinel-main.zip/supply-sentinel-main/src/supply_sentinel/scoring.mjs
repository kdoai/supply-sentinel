const SEVERITY_POINTS = {
  low: 5,
  medium: 14,
  high: 24,
  critical: 30,
};

const CONFIDENCE_POINTS = {
  low: 5,
  medium: 10,
  high: 15,
};

const ALLOWED_SEVERITY = new Set(Object.keys(SEVERITY_POINTS));
const ALLOWED_CONFIDENCE = new Set(Object.keys(CONFIDENCE_POINTS));

export function calculateRiskScore({
  riskEvent,
  inventoryDaysMin,
  impactedOrders = [],
  approvedAlternatives = [],
  affectedSupplyRatio = 0,
  spendAtRiskUsd = 0,
}) {
  const severity = normalizeEnum(riskEvent?.severity, ALLOWED_SEVERITY, "medium");
  const confidence = normalizeEnum(riskEvent?.confidence, ALLOWED_CONFIDENCE, "medium");
  const factors = {
    external_event_severity: SEVERITY_POINTS[severity],
    supplier_notice_confidence: CONFIDENCE_POINTS[confidence],
    inventory_days_risk: inventoryDaysPoints(inventoryDaysMin),
    customer_order_priority: customerPriorityPoints(impactedOrders),
    alternative_availability_risk: alternativeRiskPoints({ inventoryDaysMin, approvedAlternatives }),
    affected_supply_ratio_risk: affectedSupplyRatioPoints(affectedSupplyRatio),
    spend_at_risk_scale: spendAtRiskPoints(spendAtRiskUsd),
  };

  const score = Object.values(factors).reduce((total, points) => total + points, 0);
  return {
    score: Math.min(score, 100),
    factors,
  };
}

function inventoryDaysPoints(days) {
  if (days == null) {
    return 12;
  }
  if (days <= 7) {
    return 20;
  }
  if (days <= 14) {
    return 14;
  }
  if (days <= 30) {
    return 7;
  }
  return 0;
}

function customerPriorityPoints(orders) {
  if (orders.some((order) => order.priority === "high")) {
    return 10;
  }
  if (orders.some((order) => order.priority === "medium")) {
    return 6;
  }
  if (orders.length > 0) {
    return 2;
  }
  return 0;
}

function alternativeRiskPoints({ inventoryDaysMin, approvedAlternatives }) {
  if (approvedAlternatives.length === 0) {
    return 8;
  }

  const leadTimes = approvedAlternatives
    .map((alternative) => Number(alternative.lead_time_days))
    .filter(Number.isFinite);
  if (!leadTimes.length) {
    return 6;
  }

  const fastestLeadTime = Math.min(...leadTimes);
  if (inventoryDaysMin == null) {
    return 4;
  }
  if (fastestLeadTime <= Number(inventoryDaysMin)) {
    return 0;
  }

  const gap = fastestLeadTime - Number(inventoryDaysMin);
  return gap >= 3 ? 6 : 4;
}

function affectedSupplyRatioPoints(ratio) {
  const n = Number(ratio);
  if (!Number.isFinite(n) || n <= 0) return 0;
  if (n >= 90) return 10;
  if (n >= 75) return 7;
  if (n >= 50) return 4;
  if (n >= 25) return 2;
  return 1;
}

function spendAtRiskPoints(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return 0;
  if (n >= 20_000_000) return 7;
  if (n >= 10_000_000) return 5;
  if (n >= 5_000_000) return 3;
  if (n >= 1_000_000) return 1;
  return 0;
}

function normalizeEnum(value, allowed, fallback) {
  const text = String(value || "").toLowerCase().trim();
  return allowed.has(text) ? text : fallback;
}

export function severityFromScore(score) {
  if (score >= 85) {
    return "critical";
  }
  if (score >= 70) {
    return "high";
  }
  if (score >= 45) {
    return "medium";
  }
  return "low";
}
