// researchDiff.mjs — 実取得ニュースから「好転/悪化」を判定する純粋ロジック。
//
// 手動「シナリオ実行」で AI 調査エージェントが実際に取得した記事(タイトル/URL/日時)を、
//   1) 見出しのエスカレーション語(悪化方向)/沈静化語(改善方向)のスコア、
//   2) 前回取得スナップショットとの件数差分・新規URL、
// から総合し、ニュース見通し(improving/worsening/stable)を返す。
//
// 純粋関数: ネットワーク・DOM・壁時計に触れない。実取得した evidence(配列)と
// 前回スナップショット(任意)だけを入力にする。判定はルールベース、説明はAI(別層)。

// 供給逼迫=悪化方向の語。
const ESCALATION_TERMS = [
  "outage", "shutdown", "shut down", "halt", "halted", "force majeure", "cut", "curtail",
  "disruption", "disrupted", "shortage", "delay", "delayed", "fire", "explosion",
  "strike", "closure", "suspend", "suspended", "allocation", "rationing", "surge", "spike",
  "soar", "soars", "jump", "ban", "sanction", "shut", "tight", "tighten", "blast", "leak",
];
// 供給回復=改善方向の語。
const DEESCALATION_TERMS = [
  "restart", "restarted", "resume", "resumed", "recover", "recovery", "recovered", "ease",
  "eased", "easing", "normalize", "normalized", "normalise", "restored", "restore", "stabilize",
  "stabilized", "stabilise", "ramp up", "back online", "online again", "fall", "falls", "drop",
  "decline", "lower", "relief", "improve", "improved", "abundant", "ample", "surplus",
];

function countTerms(text, terms) {
  const t = String(text || "").toLowerCase();
  let n = 0;
  for (const term of terms) {
    if (t.includes(term)) n += 1;
  }
  return n;
}

function sign(n) {
  return n > 0 ? 1 : n < 0 ? -1 : 0;
}

// 取得した evidence([{ title|claim, url, source, published_at }]) からスナップショットを作る。
export function summarizeEvidence(evidence, material) {
  const list = Array.isArray(evidence) ? evidence : [];
  let escalation = 0;
  let deescalation = 0;
  const urls = [];
  for (const e of list) {
    const title = e.title || e.claim || "";
    escalation += countTerms(title, ESCALATION_TERMS);
    deescalation += countTerms(title, DEESCALATION_TERMS);
    if (e.url) urls.push(e.url);
  }
  return {
    material: material || null,
    count: list.length,
    escalation,
    deescalation,
    urls,
  };
}

/**
 * 実取得ニュースと前回スナップショットから好転/悪化を判定する。
 * @param {object|null} previous 前回の summarizeEvidence() 結果(無ければ初回)
 * @param {object} current       今回の summarizeEvidence() 結果
 * @returns {{ outlook, net, escalation, deescalation, count, countDelta, newUrlCount, hasPrevious, headline, summary_points }}
 */
export function diffResearch(previous, current) {
  const cur = current || { count: 0, escalation: 0, deescalation: 0, urls: [] };
  const net = cur.escalation - cur.deescalation; // 正=悪化方向
  const hasPrevious = Boolean(previous && typeof previous === "object");

  let countDelta = null;
  let newUrlCount = cur.count;
  if (hasPrevious) {
    countDelta = cur.count - (Number(previous.count) || 0);
    const prevUrls = new Set(Array.isArray(previous.urls) ? previous.urls : []);
    newUrlCount = (cur.urls || []).filter((u) => !prevUrls.has(u)).length;
  }

  // 総合シグナル: 見出しの語感(主)+ 件数の増減(従)。正=悪化 / 負=改善。
  const signal = net + (countDelta != null ? sign(countDelta) : 0);
  const outlook = signal > 0 ? "worsening" : signal < 0 ? "improving" : "stable";

  const headline = buildHeadline(cur, net, countDelta, outlook, hasPrevious);
  const summary_points = buildSummaryPoints(cur, net, countDelta, newUrlCount, hasPrevious);

  return {
    outlook,
    net,
    escalation: cur.escalation,
    deescalation: cur.deescalation,
    count: cur.count,
    countDelta,
    newUrlCount,
    hasPrevious,
    headline,
    summary_points,
  };
}

function outlookWord(outlook) {
  return { improving: "好転(改善)", worsening: "悪化", stable: "横ばい" }[outlook] || "横ばい";
}

function buildHeadline(cur, net, countDelta, outlook, hasPrevious) {
  const bits = [`実ニュース${cur.count}件取得`];
  bits.push(`悪化語${cur.escalation}/沈静化語${cur.deescalation}`);
  if (hasPrevious && countDelta != null && countDelta !== 0) {
    bits.push(`前回比${countDelta > 0 ? "+" : ""}${countDelta}件`);
  }
  return `${bits.join("・")} → ニュースは${outlookWord(outlook)}傾向`;
}

function buildSummaryPoints(cur, net, countDelta, newUrlCount, hasPrevious) {
  const points = [];
  points.push(
    net > 0
      ? `見出しに供給逼迫を示す語が優勢(悪化語${cur.escalation}/沈静化語${cur.deescalation})。`
      : net < 0
        ? `見出しに供給回復を示す語が優勢(沈静化語${cur.deescalation}/悪化語${cur.escalation})。`
        : `見出しの語感は中立(悪化語${cur.escalation}/沈静化語${cur.deescalation})。`,
  );
  if (hasPrevious && countDelta != null) {
    points.push(
      countDelta > 0
        ? `関連報道が前回より${countDelta}件増加(新規${newUrlCount}件)。注目度が上昇。`
        : countDelta < 0
          ? `関連報道が前回より${Math.abs(countDelta)}件減少。沈静化の兆し。`
          : "関連報道の件数は前回と同水準。",
    );
  } else {
    points.push("初回取得のため、これを基準スナップショットとして保存します(次回実行で差分比較)。");
  }
  return points;
}
