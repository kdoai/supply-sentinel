import { calculateRiskScore, severityFromScore } from "./scoring.mjs";

export function assessImpact(riskEvent, data, options = {}) {
  const material = riskEvent.material;
  const impactedBomRows = data.bom.filter((row) => sameMaterial(row.material, material, data.materials));
  const impactedProducts = unique(impactedBomRows.map((row) => row.product));
  const impactedOrders = data.orders.filter((order) => impactedProducts.includes(order.product));
  const inventoryRows = data.inventory.filter((row) => sameMaterial(row.material, material, data.materials));
  const impactedPlants = unique([
    ...impactedOrders.map((order) => order.plant),
    ...inventoryRows.map((row) => row.plant),
  ]);
  const inventoryAssessments = inventoryRows.map((row) => ({
    material: row.material,
    plant: row.plant,
    stock_qty: row.stock_qty,
    daily_usage: row.daily_usage,
    unit: row.unit,
    days_of_supply: round(row.stock_qty / row.daily_usage, 1),
  }));
  const inventoryDaysMin = inventoryAssessments.length
    ? Math.min(...inventoryAssessments.map((row) => row.days_of_supply))
    : null;
  const alternatives = data.alternatives.filter((row) => sameMaterial(row.material, material, data.materials));
  const approvedAlternatives = alternatives.filter((row) => row.approved === true);
  const routeKpis = options.routeIntel?.kpis || deriveRouteKpis(riskEvent, data);
  const scoring = calculateRiskScore({
    riskEvent,
    inventoryDaysMin,
    impactedOrders,
    approvedAlternatives,
    affectedSupplyRatio: routeKpis.affected_share_percent,
    spendAtRiskUsd: routeKpis.monthly_spend_at_risk,
  });
  const shortfallProjection = buildShortfallProjection({
    material,
    inventoryRows,
    impactedBomRows,
    impactedOrders,
    alternatives: approvedAlternatives,
    generatedAt: riskEvent.generated_at,
  });

  return {
    alert_id: buildAlertId(riskEvent),
    material,
    risk_type: riskEvent.risk_type,
    risk_score: scoring.score,
    severity: severityFromScore(scoring.score),
    source_severity: riskEvent.severity,
    severity_basis: {
      input_ai_severity: riskEvent.severity,
      output_policy_severity: severityFromScore(scoring.score),
      note: "入力severityはAI抽出、表示severityはスコアと企業基準から再判定。",
    },
    confidence: riskEvent.confidence,
    scoring_factors: scoring.factors,
    affected_period: riskEvent.affected_period,
    delay_days_min: riskEvent.delay_days_min,
    delay_days_max: riskEvent.delay_days_max,
    allocation_rate_percent: riskEvent.allocation_rate_percent,
    inventory_days_min: inventoryDaysMin,
    inventory: inventoryAssessments,
    impacted_products: impactedProducts,
    impacted_customers: unique(impactedOrders.map((order) => order.customer)),
    impacted_plants: impactedPlants,
    impacted_orders: impactedOrders,
    shortfall_projection: shortfallProjection,
    alternatives,
    approved_alternatives: approvedAlternatives,
    evidence: riskEvent.evidence,
    recommended_actions: recommendActions({
      riskEvent,
      impactedOrders,
      inventoryDaysMin,
      approvedAlternatives,
    }),
    approval_required: [
      "発注内容の変更",
      "サプライヤ切替",
      "顧客への正式通知",
      "生産計画の大幅変更",
    ],
    generated_at: new Date().toISOString(),
  };
}

function recommendActions({ riskEvent, impactedOrders, inventoryDaysMin, approvedAlternatives }) {
  const actions = [];
  actions.push("サプライヤへ最新の割当数量・出荷予定・代替出荷枠を確認する。");

  if (inventoryDaysMin != null && inventoryDaysMin <= 7) {
    actions.push("高優先度受注・重要工場向けに利用可能在庫を仮引当する。");
  } else if (inventoryDaysMin == null) {
    actions.push("対象材の在庫データが不足しているため、在庫残と日量消費を当日中に確認する。");
  }

  if (approvedAlternatives.length > 0) {
    const names = approvedAlternatives.map((alternative) => alternative.alternative_material).join("、");
    actions.push(`承認済み代替材（${names}）の適用範囲・リードタイム・顧客制約を確認する。`);
  } else {
    actions.push("代替材または二次サプライヤの緊急評価を開始する。");
  }

  if (impactedOrders.some((order) => order.priority === "high")) {
    actions.push("高優先顧客向けに影響可能性と暫定納期の説明ドラフトを作成する。");
  }

  if (Number(riskEvent.delay_days_max) > 0) {
    actions.push(`生産計画を${riskEvent.delay_days_min}-${riskEvent.delay_days_max}日の遅延幅で再評価する。`);
  }

  return actions;
}

function sameMaterial(left, right, materials = []) {
  return materialKey(left, materials) === materialKey(right, materials);
}

function materialKey(value, materials = []) {
  const text = String(value || "").toLowerCase();
  for (const material of Array.isArray(materials) ? materials : []) {
    const aliases = [material.material_id, material.display_name, ...(Array.isArray(material.aliases) ? material.aliases : [])]
      .filter(Boolean)
      .map((alias) => String(alias).toLowerCase());
    if (aliases.includes(text) || aliases.some((alias) => alias && text.includes(alias))) {
      return material.material_id;
    }
  }
  return text;
}

function buildShortfallProjection({ material, inventoryRows, impactedBomRows, impactedOrders, alternatives }) {
  const dailyDemandByPlant = new Map();
  for (const row of inventoryRows) {
    dailyDemandByPlant.set(row.plant, Number(row.daily_usage) || 0);
  }
  const projected = inventoryRows.map((row) => {
    const stock = Number(row.stock_qty) || 0;
    const daily = Number(row.daily_usage) || 0;
    const days = daily > 0 ? round(stock / daily, 1) : null;
    const fastestAlt = fastestAlternative(alternatives);
    const altArrivesInTime = fastestAlt != null && days != null ? fastestAlt <= days : false;
    return {
      material,
      plant: row.plant,
      stock_qty: row.stock_qty,
      daily_usage: row.daily_usage,
      days_until_shortfall: days,
      fastest_approved_alt_lead_time_days: fastestAlt,
      alternative_arrives_before_shortfall: altArrivesInTime,
      status: days == null ? "unknown" : altArrivesInTime ? "covered_by_approved_alt" : "shortfall_risk",
    };
  });
  return {
    material,
    impacted_order_count: impactedOrders.length,
    impacted_required_material_qty: impactedBomRows.reduce((sum, row) => sum + (Number(row.required_qty) || 0), 0),
    daily_usage_total: [...dailyDemandByPlant.values()].reduce((sum, value) => sum + value, 0),
    plants: projected,
  };
}

function fastestAlternative(alternatives) {
  const times = alternatives.map((row) => Number(row.lead_time_days)).filter(Number.isFinite);
  return times.length ? Math.min(...times) : null;
}

function deriveRouteKpis(riskEvent, data) {
  const routes = Array.isArray(data.supplyRoutes) ? data.supplyRoutes : [];
  let affectedShare = 0;
  let spend = 0;
  for (const route of routes) {
    if (!sameMaterial(route.material, riskEvent.material, data.materials)) continue;
    if (!regionMatches(riskEvent.region, route.region)) continue;
    affectedShare += Number(route.share_percent) || 0;
    spend += Number(route.monthly_spend_usd) || 0;
  }
  return { affected_share_percent: affectedShare, monthly_spend_at_risk: spend };
}

function regionMatches(eventRegion, routeRegion) {
  const event = String(eventRegion ?? "").toLowerCase().trim();
  const route = String(routeRegion ?? "").toLowerCase().trim();
  if (!event || !route) return false;
  if (event === route) return true;
  if (event === "asia") return ["southeast asia", "east asia", "northeast asia", "south asia"].includes(route);
  if (event === "europe") return route.includes("europe") || route === "eu";
  return false;
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function round(value, digits) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function buildAlertId(riskEvent) {
  const date = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  const material = String(riskEvent.material).replace(/[^a-z0-9]+/gi, "-").toLowerCase();
  return `alert-${date}-${material}`;
}
