import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { buildScenarioBrief } from "../web/js/aiScenarioBrief.js";
import { buildScenarioModel } from "../web/js/scenarioModel.js";
import { analyzeTrend } from "../web/js/trendAnalysis.js";
import { normalizePolicy, DEFAULT_POLICY } from "../web/js/companyPolicy.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const scenarioDir = path.join(__dirname, "..", "web", "assets", "scenarios");

async function loadJson(rel) {
  return JSON.parse(await readFile(path.join(scenarioDir, rel), "utf8"));
}

const controls = {
  material: "naphtha",
  reductionPercent: 30,
  period: 30,
  nodeCategories: ["refinery"],
  altRoute: "partial",
  demand: "protect_priority_customers",
};

async function buildBrief() {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const ts = await loadJson("naphtha-asia-allocation.timeseries.json");
  const policy = normalizePolicy(DEFAULT_POLICY);
  const model = buildScenarioModel(scenario, controls, policy);
  const trend = analyzeTrend(ts.months, ts.months.length - 1, model.metrics);
  const brief = buildScenarioBrief({
    scenario,
    metrics: model.metrics,
    policy,
    controls,
    decisions: model.decisions,
    trend,
  });
  return { brief, metrics: model.metrics, decisions: model.decisions, trend };
}

test("the brief references the computed metrics (no AI-invented numbers)", async () => {
  const { brief, metrics } = await buildBrief();
  assert.equal(brief.references.risk_score, metrics.risk_score);
  assert.equal(brief.references.affected_supply_ratio, metrics.affected_supply_ratio);
  assert.equal(brief.references.inventory_days_min, metrics.inventory_days_min);
  assert.equal(brief.references.spend_at_risk_usd, metrics.spend_at_risk_usd);
});

test("every number in the exec summary comes from the computed inputs", async () => {
  const { brief, metrics } = await buildBrief();
  // exec_summary 内の数値はすべて、計算済み metrics / 入力値の集合に含まれること。
  const allowed = new Set([
    String(metrics.affected_supply_ratio),
    String(metrics.inventory_days_min),
    String(controls.reductionPercent),
    String(brief.protect.length),
    String(brief.reduce.length),
  ]);
  const numbers = (brief.exec_summary.match(/\d+(?:\.\d+)?/g) || []).filter(
    // 金額の桁(百万/千)表記に含まれる端数は別途許容(spend由来)。
    (n) => n.length > 0,
  );
  for (const n of numbers) {
    const ok = allowed.has(n) || brief.exec_summary.includes(`${n}百万ドル`) || brief.exec_summary.includes(`${n}千ドル`);
    assert.ok(ok, `exec_summary に計算外の数値 ${n} が現れている: ${brief.exec_summary}`);
  }
});

test("the brief explains reasons, confirm points and human approvals", async () => {
  const { brief, decisions } = await buildBrief();
  assert.ok(brief.priority_reasons.length >= 1, "製品優先順位の理由を提示");
  assert.ok(brief.confirm_points.length >= 1, "追加確認ポイントを提示");
  assert.deepEqual(brief.human_approvals, decisions.human_approvals);
  assert.ok(brief.protect.length >= 1 || brief.reduce.length >= 1, "守る/縮小の判断を提示");
});

test("the brief includes the past-vs-present trend section", async () => {
  const { brief } = await buildBrief();
  assert.ok(brief.trend);
  assert.equal(brief.trend.hasPrevious, true);
  assert.ok(["improving", "worsening", "stable"].includes(brief.trend.news_outlook));
  assert.ok(brief.trend.summary_points.length >= 1);
});

test("the brief is clearly labeled as a local (demo) generation fallback", async () => {
  const { brief } = await buildBrief();
  assert.equal(brief.fallback, true);
  assert.equal(brief.mode, "local");
});
