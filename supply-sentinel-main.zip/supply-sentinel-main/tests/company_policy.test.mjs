import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  classifyWarningLevel,
  productPriorityScore,
  normalizePolicy,
  applyDemandPolicy,
  DEFAULT_POLICY,
} from "../web/js/companyPolicy.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

test("company_policy.demo.json matches the documented thresholds and weights (§11.2)", async () => {
  const raw = await readFile(
    path.join(__dirname, "..", "web", "assets", "company_policy.demo.json"),
    "utf8",
  );
  const policy = JSON.parse(raw);
  assert.equal(policy.company_policy_name, "Demo Manufacturing SCM Policy");
  assert.equal(policy.thresholds.attention.min_inventory_days, 30);
  assert.equal(policy.thresholds.danger.min_inventory_days, 14);
  assert.equal(policy.thresholds.stop_or_allocation_decision.min_inventory_days, 7);
  assert.equal(policy.priority_weights.customer_priority, 0.3);
  assert.equal(policy.priority_weights.revenue_impact, 0.25);
});

test("changing the danger inventory threshold changes the warning level (§21.3)", () => {
  // 在庫10日・影響供給比率10%(=比率では危険にならない)。在庫日数で判定が決まる。
  const base = normalizePolicy(DEFAULT_POLICY);
  assert.equal(classifyWarningLevel(10, 10, base), "danger"); // 10 <= danger(14)

  const tightened = normalizePolicy({
    ...DEFAULT_POLICY,
    thresholds: {
      ...DEFAULT_POLICY.thresholds,
      danger: { min_inventory_days: 7, affected_supply_ratio_percent: 50 },
    },
  });
  // 危険閾値を 14→7日 に変更すると、10日は危険から外れ「注意」へ。
  assert.equal(classifyWarningLevel(10, 10, tightened), "attention");
});

test("the most severe matching level wins (stop by ratio, danger by inventory)", () => {
  const p = normalizePolicy(DEFAULT_POLICY);
  assert.equal(classifyWarningLevel(40, 75, p), "stop_or_allocation_decision"); // 75% >= 70
  assert.equal(classifyWarningLevel(40, 10, p), "none"); // 40日 / 10% はどの閾値も超えない
});

test("changing priority weights reorders products (§21.4)", () => {
  // X: 高優先顧客・低売上 / Y: 低優先顧客・高売上
  const x = { customer_priority: 1.0, revenue_impact: 0.1, inventory_days: 0.5, alternative_availability: 0.5, single_supplier_dependency: 0.5 };
  const y = { customer_priority: 0.2, revenue_impact: 1.0, inventory_days: 0.5, alternative_availability: 0.5, single_supplier_dependency: 0.5 };

  const customerHeavy = { customer_priority: 0.6, revenue_impact: 0.1, inventory_days: 0.1, alternative_availability: 0.1, single_supplier_dependency: 0.1 };
  assert.ok(productPriorityScore(x, customerHeavy) > productPriorityScore(y, customerHeavy), "顧客重視ならX優先");

  const revenueHeavy = { customer_priority: 0.1, revenue_impact: 0.6, inventory_days: 0.1, alternative_availability: 0.1, single_supplier_dependency: 0.1 };
  assert.ok(productPriorityScore(y, revenueHeavy) > productPriorityScore(x, revenueHeavy), "売上重視ならY優先(順位が入れ替わる)");
});

test("applyDemandPolicy adjusts weights without mutating the source", () => {
  const base = normalizePolicy(DEFAULT_POLICY).priority_weights;
  const protect = applyDemandPolicy(base, "protect_priority_customers");
  assert.ok(protect.customer_priority > base.customer_priority, "高優先顧客を守る→顧客重みが増える");
  const revenue = applyDemandPolicy(base, "maximize_revenue");
  assert.ok(revenue.revenue_impact > base.revenue_impact, "売上最大化→売上重みが増える");
  // 元の重みは不変。
  assert.equal(base.customer_priority, 0.3);
});

test("normalizePolicy fills missing fields with defaults", () => {
  const p = normalizePolicy({ thresholds: { danger: { min_inventory_days: 9 } } });
  assert.equal(p.thresholds.danger.min_inventory_days, 9);
  assert.equal(p.thresholds.attention.min_inventory_days, 30); // 既定で補完
  assert.equal(p.priority_weights.customer_priority, 0.3);
  assert.equal(p.company_policy_name, "Demo Manufacturing SCM Policy");
});
