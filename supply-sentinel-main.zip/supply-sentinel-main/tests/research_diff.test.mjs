import test from "node:test";
import assert from "node:assert/strict";

import { summarizeEvidence, diffResearch } from "../src/supply_sentinel/researchDiff.mjs";
import { scenarioResearch } from "../src/function_app/httpScenarioResearch.mjs";

// --- pure diff logic --------------------------------------------------------

test("summarizeEvidence counts escalation/de-escalation terms and urls", () => {
  const snap = summarizeEvidence(
    [
      { title: "Naphtha refinery outage triggers allocation cuts", url: "https://a/1" },
      { title: "Asia naphtha supply shortage deepens", url: "https://a/2" },
      { title: "Prices ease as plants restart and supply recovers", url: "https://a/3" },
    ],
    "naphtha",
  );
  assert.equal(snap.count, 3);
  assert.ok(snap.escalation >= 3, "outage/allocation/cut/shortage detected");
  assert.ok(snap.deescalation >= 2, "ease/restart/recover detected");
  assert.equal(snap.urls.length, 3);
});

test("escalation-heavy fresh news is judged worsening", () => {
  const cur = summarizeEvidence(
    [
      { title: "Refinery shutdown and force majeure halt naphtha output", url: "https://a/1" },
      { title: "Allocation cuts widen amid supply disruption", url: "https://a/2" },
    ],
    "naphtha",
  );
  const diff = diffResearch(null, cur);
  assert.equal(diff.outlook, "worsening");
  assert.equal(diff.hasPrevious, false);
  assert.match(diff.headline, /実ニュース2件/);
});

test("recovery-heavy fresh news is judged improving", () => {
  const cur = summarizeEvidence(
    [
      { title: "Naphtha supply normalizes as refineries restart", url: "https://a/1" },
      { title: "Prices fall and inventories recover", url: "https://a/2" },
    ],
    "naphtha",
  );
  const diff = diffResearch(null, cur);
  assert.equal(diff.outlook, "improving");
});

test("a rising count vs the previous snapshot pushes toward worsening", () => {
  const previous = { count: 1, escalation: 0, deescalation: 0, urls: ["https://a/old"] };
  const cur = summarizeEvidence(
    [
      { title: "Naphtha market update", url: "https://a/1" },
      { title: "Naphtha logistics note", url: "https://a/2" },
      { title: "Naphtha contract roundup", url: "https://a/3" },
    ],
    "naphtha",
  );
  const diff = diffResearch(previous, cur);
  assert.equal(diff.hasPrevious, true);
  assert.equal(diff.countDelta, 2);
  assert.equal(diff.newUrlCount, 3);
  assert.equal(diff.outlook, "worsening"); // neutral wording but coverage rose
});

// --- endpoint with injected fetch (no real network) -------------------------

function rssXml(titles) {
  const items = titles
    .map((t, i) => `<item><title>${t}</title><link>https://news.example/${i}</link><pubDate>Mon, 01 Jun 2026 08:00:00 GMT</pubDate><description>${t}</description></item>`)
    .join("");
  return `<?xml version="1.0"?><rss><channel>${items}</channel></rss>`;
}

test("scenarioResearch (no Azure) does a real RSS-style search via injected fetch and returns grounded evidence", async () => {
  const fetchImpl = async () => ({
    ok: true,
    status: 200,
    text: async () => rssXml(["Naphtha refinery outage cuts allocation - Reuters", "Asia naphtha shortage deepens - Bloomberg"]),
  });
  const result = await scenarioResearch(
    { material: "naphtha", materialLabel: "ナフサ", previous: null },
    { fetchImpl, mode: "demo", config: {} }, // demo mode => RSS path, no LLM
  );
  assert.equal(result.mode, "rss");
  assert.ok(result.evidence.length >= 2);
  assert.ok(result.evidence[0].url.startsWith("https://"), "evidence carries a real URL");
  assert.ok(result.queries[0].includes("naphtha"), "query built from material");
  assert.equal(result.diff.outlook, "worsening");
});

test("scenarioResearch never throws and reports unavailable when the search fails", async () => {
  const fetchImpl = async () => {
    throw new Error("network down");
  };
  const result = await scenarioResearch(
    { material: "naphtha", materialLabel: "ナフサ" },
    { fetchImpl, mode: "demo", config: {} },
  );
  assert.equal(result.mode, "unavailable");
  assert.deepEqual(result.evidence, []);
  assert.equal(result.diff.count, 0);
});
