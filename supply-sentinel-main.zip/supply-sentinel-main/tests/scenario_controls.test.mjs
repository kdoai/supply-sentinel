import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { buildScenarioModel } from "../web/js/scenarioModel.js";
import { analyzeTrend } from "../web/js/trendAnalysis.js";
import { DEFAULT_POLICY } from "../web/js/companyPolicy.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const scenarioDir = path.join(__dirname, "..", "web", "assets", "scenarios");

async function loadJson(rel) {
  return JSON.parse(await readFile(path.join(scenarioDir, rel), "utf8"));
}

function controls(overrides) {
  return {
    material: "naphtha",
    reductionPercent: 30,
    period: 30,
    nodeCategories: ["refinery"],
    altRoute: "partial",
    demand: "protect_priority_customers",
    ...overrides,
  };
}

test("default controls reproduce the locked naphtha invariants (65% / 5日 / 82)", async () => {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const model = buildScenarioModel(scenario, controls(), DEFAULT_POLICY);
  assert.equal(model.metrics.affected_supply_ratio, 65);
  assert.equal(model.metrics.inventory_days_min, 5);
  assert.equal(model.metrics.risk_score, 82);
  assert.equal(model.metrics.impacted_products.length, 3);
});

test("raising the supply reduction worsens endurance and risk (§24.1)", async () => {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const at30 = buildScenarioModel(scenario, controls({ reductionPercent: 30 }), DEFAULT_POLICY);
  const at60 = buildScenarioModel(scenario, controls({ reductionPercent: 60 }), DEFAULT_POLICY);
  assert.ok(at60.metrics.inventory_days_min < at30.metrics.inventory_days_min, "在庫残日数が悪化");
  assert.ok(at60.metrics.risk_score >= at30.metrics.risk_score, "リスクが上がる");
});

test("lowering the supply reduction improves endurance and risk", async () => {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const at30 = buildScenarioModel(scenario, controls({ reductionPercent: 30 }), DEFAULT_POLICY);
  const at10 = buildScenarioModel(scenario, controls({ reductionPercent: 10 }), DEFAULT_POLICY);
  assert.ok(at10.metrics.inventory_days_min > at30.metrics.inventory_days_min, "在庫残日数が改善");
  assert.ok(at10.metrics.risk_score < at30.metrics.risk_score, "リスクが下がる");
});

test("changing the impacted nodes changes affected supply ratio and impacted products", async () => {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const refineryOnly = buildScenarioModel(scenario, controls({ nodeCategories: ["refinery"] }), DEFAULT_POLICY);
  const allTier1 = buildScenarioModel(scenario, controls({ nodeCategories: ["tier1"] }), DEFAULT_POLICY);
  // 全Tier1サプライヤを止めると、中東ルートも含め全調達が影響を受ける。
  assert.ok(allTier1.metrics.affected_supply_ratio > refineryOnly.metrics.affected_supply_ratio);
  assert.equal(allTier1.metrics.affected_supply_ratio, 100);
});

test("the demand policy changes product priority scores", async () => {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const protect = buildScenarioModel(scenario, controls({ demand: "protect_priority_customers" }), DEFAULT_POLICY);
  const revenue = buildScenarioModel(scenario, controls({ demand: "maximize_revenue" }), DEFAULT_POLICY);
  const protectScores = protect.decisions.products.map((p) => p.priority_score).join(",");
  const revenueScores = revenue.decisions.products.map((p) => p.priority_score).join(",");
  assert.notEqual(protectScores, revenueScores, "需要方針で優先順位スコアが変わる");
});

test("scenario produces per-product decisions including a protected product", async () => {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const model = buildScenarioModel(scenario, controls(), DEFAULT_POLICY);
  const decisions = model.decisions;
  assert.ok(decisions.products.length >= 3);
  // 樹脂A は高優先顧客 + 承認済み代替材 → 供給配分(守る)。
  const resinA = decisions.products.find((p) => p.product === "樹脂A");
  assert.ok(resinA);
  assert.equal(resinA.decision, "allocate");
  // 溶剤B は高優先だが代替材未承認 → 代替材確認。
  const solventB = decisions.products.find((p) => p.product === "溶剤B");
  assert.equal(solventB.decision, "alt_check");
  // 人間承認が必要な判断が積み上がる。
  assert.ok(decisions.human_approvals.includes("発注内容の変更"));
  assert.ok(decisions.human_approvals.includes("供給配分判断"));
});

test("a naphtha-derivative material (lower exposure) is less affected than raw naphtha (§10.1)", async () => {
  const scenario = await loadJson("naphtha-asia-allocation.json");
  const naphtha = buildScenarioModel(scenario, controls({ materialExposure: 1 }), DEFAULT_POLICY);
  // PP はナフサ由来・依存度0.75 としてナフサ供給網で評価。
  const pp = buildScenarioModel(scenario, controls({ materialExposure: 0.75 }), DEFAULT_POLICY);
  const other = buildScenarioModel(scenario, controls({ materialExposure: 0.4 }), DEFAULT_POLICY);
  assert.ok(pp.metrics.affected_supply_ratio < naphtha.metrics.affected_supply_ratio, "PPはナフサより影響供給比率が低い");
  assert.ok(other.metrics.affected_supply_ratio < pp.metrics.affected_supply_ratio, "その他石化素材はさらに低い");
  assert.ok(pp.metrics.inventory_days_min >= naphtha.metrics.inventory_days_min, "依存度が低いほど耐久が伸びる");
  assert.ok(other.metrics.risk_score <= naphtha.metrics.risk_score, "依存度が低いほどリスクは下がる");
  // exposure=1 既定では不変(ナフサと一致)。
  assert.equal(naphtha.metrics.affected_supply_ratio, 65);
});

test("analyzeTrend judges improvement vs worsening from past months", () => {
  const months = [
    { label: "前月", metrics: { risk_score: 60, affected_supply_ratio: 40, inventory_days_min: 9 }, price_index: 105 },
    { label: "現在", metrics: { risk_score: 82, affected_supply_ratio: 65, inventory_days_min: 5 }, price_index: 112 },
  ];
  const worse = analyzeTrend(months, 1, { risk_score: 82, affected_supply_ratio: 65, inventory_days_min: 5 });
  assert.equal(worse.hasPrevious, true);
  assert.equal(worse.overall, "worsening");
  assert.equal(worse.news_outlook, "worsening");

  const better = analyzeTrend(months, 1, { risk_score: 40, affected_supply_ratio: 20, inventory_days_min: 18 });
  assert.equal(better.overall, "improving");
  assert.equal(better.news_outlook, "improving");

  const baseline = analyzeTrend(months, 0, { risk_score: 60 });
  assert.equal(baseline.hasPrevious, false);
});
